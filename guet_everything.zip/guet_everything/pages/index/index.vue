<template>
	<!-- <uni-nav-bar left-icon="back" left-text="返回" title="guet_everything" statusBar='true' backgroundColor='#114783' color='#eef1f4'></uni-nav-bar> -->
	<uni-nav-bar title="桂电校友圈" statusBar='true' backgroundColor='#447db9' color='#eaebeb' fixed='true' ></uni-nav-bar>
	 <view></view>
</template>

<script setup>
	import {onLoad,onReady} from "@dcloudio/uni-app"
	import {computed} from 'vue'
	import { getCurrentInstance } from 'vue'
		const {
			appContext: {
				config: {
					globalProperties: global
				}
			}
		} = getCurrentInstance();
		
		
		const CpCustomBar = computed(()=>{
			return global.CustomBar*2+'rpx'
		})
		console.log(CpCustomBar,global)
</script>
<script>
	export default {
		data() {
			return {
			}
		}
	}
</script>
<style>
	.container {
		padding: 20px;
		font-size: 14px;
		line-height: 24px;
	}
</style>
