<template>
	<view>
		<!-- <uni-nav-bar title="登录" statusBar='true' backgroundColor='#447db9' color='#eaebeb' ></uni-nav-bar> -->
		<view class="everything">Everything</view>
		<view class="guet">—— GUET</view>
		<view class="title">微信一键授权登录</view>
		<button class="loginButton" @click="oneStepLogin">立即登录</button>
		<view class="phoneBox">
			<view class="phoneFont">使用手机号进行登录</view>
			<view class="rightArrow">
				<image src="../../static/右箭头 (3).png"></image>
			</view>
		</view>
		<view class="bottom" @click="backToIndex">暂不登录</view>
	</view>
</template>

<script setup>
	import { getCurrentInstance } from 'vue';
	const {
			appContext: {
				config: {
					globalProperties: global
			}
				}
		} = getCurrentInstance();
	var userInfo ={}
	var code = ''
	function oneStepLogin(){
		uni.getSetting({
			success:(res)=>{
				console.log(res)
				if(res.authSetting['scope.useInfo']){
					uni.getUserInfo({
						success: (res) => {
							userInfo = res.userInfo
							console.log('userInfo',userInfo)
							toLogin(userInfo)
						}
					})
				}else{
					wx.authorize({
						scope:'scope.userInfo',
						success:()=>{
							uni.getUserInfo({
								success:(res)=>{
									userInfo = res.userInfo
									console.log('userInfo',userInfo)
									toLogin(userInfo)
								},
								fail:(err) =>{
									console.log('用户拒绝信息授权')
									toLogin(userInfo)
								}
							})
						}
					})
				}
			}
		})
		
	}
	function toLogin(userInfo){
		uni.login({
			success: (res) => {
				console.log(res)
				code = res.code
				console.log('code',code)
				uni.request({
					url:'http://127.0.0.1:3007/user/trylogin',
					data:{
						code:code,
						userInfo:userInfo
					},
					method:'POST',
					header: {
						'content-type': 'application/json'
					},
					success:(res)=>{
						console.log(res)
						if(res.statusCode==200){
							global.userInfo = userInfo
							const tokens = {
								accessToken:res.data.accessToken,
								refreshtoken:res.data.refreshToken
							}
							uni.setStorage({
								key:'tokens',
								data:tokens,
								success: (e) => {
									console.log(e)
								},
								fail:(err)=> {
									console.log(err)
								}
							})
						}
					},
					fail: (err) => {
						console.log(err)
					}
				})
			},
			fail: (err) => {
				console.log(err)
			}
		})
	}
	function backToIndex (){
		uni.switchTab({
			url:'../index/index'
		})
	}
</script>

<style>
	page{
		background-color: #2e7bcc;
	}
	.everything{font-size: 80rpx;
		color: #fafafa;
		margin:400rpx 0 0 175rpx;
		font-weight: 600;
		font-family: 'Times New Roman', Times, serif;
		}
	.guet{
		font-size: 37rpx;
		color: #fafafa;
		margin:30rpx 0 0 500rpx;
		font-weight: 600;
		font-family: 'Times New Roman', Times, serif;
	}
	.title{
		font-size: 35rpx;
		color: #ededef;
		margin:300rpx 0 0 225rpx;
		/* font-weight: 600; */
	}
	.loginButton{
		width: 60%;
		margin: 100rpx 0 50rpx 20%;
		color: aliceblue;
		background-color: #3bb9ea;
		border-radius: 50rpx;
	}
	.phoneBox{
		display: flex;
		align-items: center;
		margin-left: 35%;
	}
	
	.phoneFont {
		color: #dedede;
		font-size: 23rpx;
	}
	.rightArrow{
		
	}
	.rightArrow image{
		width: 22rpx;
		height: 22rpx;
		margin-left: 8rpx;
	}
	.bottom {
		color: #cacaca;
		font-size: 23rpx;
		width: 100rpx;
		margin-top: 50rpx;
		border-bottom: #cacaca solid 2rpx;
		margin-left: 43%;
	}
</style>
