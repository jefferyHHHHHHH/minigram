<template>
	<view class="minePage">
		<view class="topView" :style="statusBarHeight">
			<view class="mineInfo" @click="navigateToMyInfo">
				<view class="avatarBox">
					<image src="../../static/头像.png"></image>
				</view>
				<view class="najorBox">
					<view class="name">jefly</view>
					<view class="major">计算机科学与技术</view>
				</view>
			</view>
			<view class="detailInfo">
				<view class="detailBox">
					<view class="deSbj">帖子</view>
					<view class="deNum">11</view>
				</view> 
				<view class="detailBox">
					<view class="deSbj">评论</view>
					<view class="deNum">0</view>
				</view> 
				<view class="detailBox">
					<view class="deSbj">收藏</view>
					<view class="deNum">6</view>
				</view> 
				<view class="detailBox">
					<view class="deSbj">足迹</view>
					<view class="deNum">5</view>
				</view> 
			</view>
		</view>
		<view class="bottomView">
			<view class="NavsBox">
				<view class="hangNav bodeBotom"> 
					<view class="navImgbox ">
						<image src="../../static/设置 (2).png"></image>
					</view> 
					<view class="navName">设置</view> 
					<view class="arrowBox">
						<image src="../../static/右箭头 (4).png"></image>
					</view> 
				</view>
				<view class="hangNav bodeBotom"> 
					<view class="navImgbox">
						<image src="../../static/设置 (2).png"></image>
					</view> 
					<view class="navName">设置</view> 
					<view class="arrowBox">
						<image src="../../static/右箭头 (4).png"></image>
					</view> 
				</view>
				<view class="hangNav"> 
					<view class="navImgbox">
						<image src="../../static/设置 (2).png"></image>
					</view> 
					<view class="navName">设置</view> 
					<view class="arrowBox">
						<image src="../../static/右箭头 (4).png"></image>
					</view> 
				</view>
				<!-- <view class="hangNav">
					<view class="navImgbox">
						<image></image>
					</view> 
					<view class="navName"></view> 
					<view class="arrow"></view> 
				</view> -->
			</view>	
		</view>
	</view>
</template>
<script setup>
	import {onLoad,onReady,onShow} from "@dcloudio/uni-app"
	import {computed} from 'vue'
	import { getCurrentInstance, ref} from 'vue'
		const {
			appContext: {
				config: {
					globalProperties: global
				}
			}
		} = getCurrentInstance();
		const StatusBar = ref(global.StatusBar);
		const statusBarHeight = computed(()=>({
			paddingTop:`${StatusBar.value*2}rpx`
		}))
		function navigateToMyInfo(){
			uni.navigateTo({
				url:'../../tieBaPages/userIndex/userIndex'
			})
		}
		onLoad(()=>{
			console.log('mine.vue onLoad')
		})
		onShow(()=>{
			console.log('mine.vue onshow')
		})
		
		
</script>
<style>
	.topView{
		height:380rpx;
		width: 100%;
		background-color: #447db9;
	}
	.mineInfo{
		display: flex;
		padding: 85rpx 50rpx 0rpx;
	}
	.avatarBox image{
		width:130rpx;
		height: 130rpx;
	}
	.najorBox{
		padding-left: 20rpx;
		display: flex;
		flex-direction: column;
		justify-content: center;
	}
	.name{
		font-size:35rpx;
		color: aliceblue;
	}
	.major{
		font-size: 29rpx;
		color: aliceblue;
		opacity: 0.6;
	}
	.detailInfo{
		display: flex;
		width: 100%;
		height: 150rpx;
		color: aliceblue;
	}
	.detailBox{
		width: 25%;
		padding: 20rpx;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}
	.deSbj{
		font-size: 23rpx;
		opacity: 0.6;
	}
	.deNum {
		padding-top: 15rpx;
		font-size: 36rpx;
	}
	.NavsBox{
		border: 1rpx solid #e6e6e6;
		width: 94%;
		margin: 3%;
		background-color: #ffffff;
		border-radius: 20rpx;
	}
	.hangNav {
		display: flex;
		padding:25rpx 0 25rpx;
		margin:0 40rpx 0 40rpx;
		align-items: center;
	}
	.arrowBox image {
		width: 27rpx;
		height: 27rpx;
		padding-left: 450rpx;
	}
	.navName {
		padding-left: 20rpx;
		color: #222222;
		font-size: 26rpx;
		color: #767676;
	}
	.navImgbox{
		width: 55rpx;
		height: 55rpx;
		display: flex;
		justify-content: center;
	}
	.navImgbox image {
		margin-top: 10rpx;
		width: 40rpx;
		height: 40rpx;
	}
	.bodeBotom{

		border-bottom: 5rpx #f7f7f7 solid;
	}
</style>
