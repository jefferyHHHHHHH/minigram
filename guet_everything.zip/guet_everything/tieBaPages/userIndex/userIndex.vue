<template>
	<view>
		<view class="nav-bar" :style="{height:navBarHeight,opacity:navBarOpacity}"></view>	
		<view class="leftArrow" :style="{top:LeftArrowTop}" @click="navigateBack">
			<image src="../../static/左箭头.png"></image>
		</view>
		<view class="navBarTitle" :style="{top:LeftArrowTop}">个人主页</view>
		
		<view class="topBox" :class="isFixed?'fixedTopBox':''">
			<!-- <image src="../../static/backgroundIMG.png"></image> -->
		</view>
		<view class="infoBox">
			<view class="avaNamBox">
				<view class="userAvatarBox">
					<image src="../../static/htt_avatar.jfif"></image>
				</view>
				<view class="name_fen_guan_fred">
					<view class="name">hututu</view>
					<view class="fen_guan_fred">
						<view class="countUp">
							<view class="count">20</view>
							<view class="countTitle">粉丝</view>
						</view>
						<view class="countUp">
							<view class="count">15</view>
							<view class="countTitle">关注</view>
						</view>
						<view class="countUp">
							<view class="count">2</view>
							<view class="countTitle">朋友</view>
						</view>
					</view>
				</view>
			</view>	
			<view class="jianjie">
				{{jianjie}}
			</view>
			
			<view class="editButton">
				<view class="editIcon">
					<image src="../../static/编辑.png"></image>
				</view>
				<view class="editFont">
					编辑个人资料
				</view>
			</view>
			
			<view class="tabbar">
				<view :class="[selected==1?'selectedItem':'unselectedItem']" @click="changeSelect(1)">攒局</view>
				<view :class="[selected==2?'selectedItem':'unselectedItem']" @click="changeSelect(2)">帖子</view>
				<view :class="[selected==3?'selectedItem':'unselectedItem']" @click="changeSelect(3)">收藏</view>
			</view>
			<view class="selectLine" :style="{left:lineLeft}" data-=""></view>
			
			<view v-if="selected==1" class="zanDetail normal">
				lalala
			</view>
			
			<view v-if="selected==2" class="tieDetail normal">
				<view class="tieItem" v-for="(tieItem,index) in tieArray" :key="index">
					<view class="avatarBox">
						<image :src="tieItem.avatarUrl" ></image>
					</view>
					<view class="infoBox">
						<view class="name_time">
							<view class="name">{{tieItem.nickName}}</view>
							<view class="time">{{tieItem.uploadTime}}</view>
						</view>
						<view class="content">{{tieItem.content}}</view>
						<view class="images">
							<view class="imageItem" v-if="tieItem.images!==null" v-for="(imageItem,imageIndex) in tieItem.images" key="'tieItem-'+imageItem">
								<image mode="aspectFill" :src="imageItem.src"></image>
							</view>
						</view>	
						<view class="table">{{tieItem.table}}</view>
						<view class="buttons">
							<view class="paiseBox">
								<view class="paiseImgBox">
									<!-- <image  src="../../static/点赞 (3).png"></image> -->
									<image src="../../static/点赞 (2).png"></image>
								</view>
								<view class="paiseCount" v-if="tieItem && tieItem.paise && tieItem.paise.length !== 0">{{tieItem.paise.length}}</view>
							</view>
							<view class="commentsBox">
								<view class="commentsImgBox">
									<image src="../../static/评论 (1).png" ></image>
								</view>
								<view class="commentsCount" v-if="tieItem&&tieItem.comments&&tieItem.comments.length!==0">{{tieItem.comments.length}}</view>
								<view class="commentsFont" v-else>评论</view>
							</view>
						</view>
					</view>
				</view>
				
			</view>
			
			<view v-if="selected==3" class="shoucang normal">
				heiheihei
			</view>
			
		</view>
	</view>
	<view class="bottom"></view>
</template>

<script setup>
	import {onLoad,onReady,onShow,onUnload,onPageScroll} from "@dcloudio/uni-app"
	import { getCurrentInstance,ref,computed } from 'vue';
	const {
		appContext:{
			config:{
				globalProperties:global
			}
		}
	} = getCurrentInstance();
	console.log(global,global.Custom.bottom,global.Custom.height*2);
	const navBarHeight = global.Custom.bottom*2+15+"rpx";
	const LeftArrowTop = global.Custom.bottom*2-60+"rpx";
	console.log(navBarHeight,LeftArrowTop)
	var scrollTop = ref(0);
	var navBarOpacity = computed(()=>{
		if(scrollTop.value >100){
			return 1;
		}else{
			return scrollTop.value/100;
		}
	})
	var navBarFontOpacity = computed(()=>{
		return 1-navBarOpacity
	})
	var isFixed = computed(()=>{
		if(scrollTop.value>=240){
			return true;
		}else {
			return false;
		}
	})
	const scrollHeight = computed(()=>{
		return global.safeArea.bottom*2+"rpx";
	})
	
	const jianjie = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	console.log(scrollHeight,global.safeArea)
	var selected = ref(2);
	var lineLeft =computed(()=>{
		switch (selected.value){
			case 1:return '206rpx'
				break;
			case 2:return '356rpx'
				break;
			case 3:return '506rpx'
			default:return '356rpx'
				break;
		}
	})
	
	function navigateBack(){
		uni.navigateBack()
	}
	function changeSelect(e){
		console.log(e)
		if(e==selected.value){
			return;
		}else{
			selected.value=e;
		}
		console.log(lineLeft);
	}
	onPageScroll((e)=>{
		console.log(e);
		scrollTop.value = e.scrollTop;
		console.log(scrollTop ,navBarOpacity._value);
	})
	
	const tieArray = [
		{
			nickName:'hututua',
			avatarUrl:'../../static/头像.png',
			content:'你好我是hututu',
			table:'#日常生活',
			uploadTime:'2024.7.17',
			images:[
				{
					src:'https://tse1-mm.cn.bing.net/th/id/OIP-C.MyCFkjbD54CdB-mPLrfDfAHaEo?rs=1&pid=ImgDetMain',
				}
			],
			paise:[
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				}
			],
			comments:[
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					content:'hututu快来niuyeye家玩',
					paise:[
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						}
					]
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					content:'hututu快来niuyeye家玩',
					paise:[
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:''
						}
					]
				}
			]
		},
		{
			nickName:'hututu',
			avatarUrl:'../../static/头像.png',
			content:'你好我是hututu',
			table:'#日常生活',
			uploadTime:'2024.7.17',
			images:[
				{
					src:'https://tse1-mm.cn.bing.net/th/id/OIP-C.MyCFkjbD54CdB-mPLrfDfAHaEo?rs=1&pid=ImgDetMain',
				},
				{
					src:'https://tse1-mm.cn.bing.net/th/id/OIP-C.MyCFkjbD54CdB-mPLrfDfAHaEo?rs=1&pid=ImgDetMain',
				}
			],
			paise:[
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				}
			],
			comments:[
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					content:'hututu快来niuyeye家玩',
					paise:[
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						}
					]
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					content:'hututu快来niuyeye家玩',
					paise:[
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:''
						}
					]
				}
			]
		},
		{
			nickName:'hututu',
			avatarUrl:'../../static/头像.png',
			content:'你好我是hututu',
			table:'#日常生活',
			uploadTime:'2024.7.17',
			images:[
				{
					src:'https://tse1-mm.cn.bing.net/th/id/OIP-C.MyCFkjbD54CdB-mPLrfDfAHaEo?rs=1&pid=ImgDetMain',
				},
				{
					src:'https://tse1-mm.cn.bing.net/th/id/OIP-C.MyCFkjbD54CdB-mPLrfDfAHaEo?rs=1&pid=ImgDetMain',
				}
			],
			paise:[
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				}
			],
			comments:[
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					content:'hututu快来niuyeye家玩',
					paise:[
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						}
					]
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					content:'hututu快来niuyeye家玩',
					paise:[
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:''
						}
					]
				}
			]
		},
		{
			nickName:'hututu',
			avatarUrl:'../../static/头像.png',
			content:'你好我是hututu',
			table:'#日常生活',
			uploadTime:'2024.7.17',
			images:[
				{
					src:'https://tse1-mm.cn.bing.net/th/id/OIP-C.MyCFkjbD54CdB-mPLrfDfAHaEo?rs=1&pid=ImgDetMain',
				},
				{
					src:'https://tse1-mm.cn.bing.net/th/id/OIP-C.MyCFkjbD54CdB-mPLrfDfAHaEo?rs=1&pid=ImgDetMain',
				}
			],
			paise:[
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				}
			],
			comments:[
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					content:'hututu快来niuyeye家玩',
					paise:[
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						}
					]
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					content:'hututu快来niuyeye家玩',
					paise:[
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:''
						}
					]
				}
			]
		},
		{
			nickName:'hututu',
			avatarUrl:'../../static/头像.png',
			content:'你好我是hututu,asdfjhasdkjfhsajdfhakjsdfhaksdjhfkjasdhfalkshdfklscvkaskdhfkxcvkjasnfkjsadfjkakjsdhfkjashfjksdf',
			table:'#日常生活',
			uploadTime:'2024.7.17',
			images:[
				{
					src:'https://tse1-mm.cn.bing.net/th/id/OIP-C.MyCFkjbD54CdB-mPLrfDfAHaEo?rs=1&pid=ImgDetMain',
				},{
					src:'https://tse1-mm.cn.bing.net/th/id/OIP-C.MyCFkjbD54CdB-mPLrfDfAHaEo?rs=1&pid=ImgDetMain',
				},{
					src:'https://tse1-mm.cn.bing.net/th/id/OIP-C.MyCFkjbD54CdB-mPLrfDfAHaEo?rs=1&pid=ImgDetMain',
				},
				{
					src:'https://tse1-mm.cn.bing.net/th/id/OIP-C.MyCFkjbD54CdB-mPLrfDfAHaEo?rs=1&pid=ImgDetMain',
				}
			],
			paise:[
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					openid:''
				}
			],
			comments:[
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					content:'hututu快来niuyeye家玩',
					paise:[
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						}
					]
				},
				{
					nickName:'niuyeye',
					avatarUrl:'../../static/头像.png',
					content:'hututu快来niuyeye家玩',
					paise:[
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:'../../static/头像.png'
						},
						{
							nickName:'hututu',
							openid:'',
							avatarUrl:''
						}
					]
				}
			]
		},
		
	]
	
</script>

<style>

	.nav-bar{
		/* background-color: #092438; */
		background-color: #447db9; 
		position: fixed;
		width: 100%;
		top: 0;
		z-index: 1500;
	}
	.navBarTitle{
		background-color: #447db9; 
		width: 130rpx;
		position: fixed;
		color: #ffffff;
		left: 300rpx;
	}
	.leftArrow{
		position: fixed;
		left: 20rpx;
		z-index: 2000;
	}
	.leftArrow image{
		width: 50rpx;
		height: 50rpx;
	}
	.avatarBox{
		margin-left: 30rpx;
	}
	.userAvatarBox image {
		width: 120rpx;
		height: 120rpx;
		border-radius: 100%;
		position: relative;
		top: -40rpx;
		border: 10rpx solid #fffffd;
		margin-left: 30rpx;
	}
	.topBox{
		width: 100%;
		height: 300rpx;
		background-color: #447db9;
	}
	.fixedTopBox{
		display: fixed;
		top: 480rpx;
	}
	.topBox image{
		width: 100%;
		height: 350rpx;
	}
	.infoBox{
		width: 100%;
		z-index: 999;
		border-radius: 20rpx 20rpx 0 0;
		background-color: #fffffd;	
	}
	.name_fen_guan_fred {
		
	}
	.fen_guan_fred{
		display: flex;
	}
	.name {
		font-size: 32rpx;
		color: #333333;
		margin: 20rpx 0 0 30rpx;
		font-weight: 600;
	}
	.countUp{
		display: flex;
		margin: 10rpx 20rpx 10rpx;
		justify-content: center;
	}
	.count{
		color: #333333;
		margin-right: 10rpx;
		font-weight: 600;
	}
	.countTitle{
		color: #979797;
		font-size: 29rpx;
	}
	.avaNamBox{
		display: flex;
	}
	.jianjie{
		width: 90%;
		margin:10rpx 0 0rpx 5%;
		padding-bottom: 20rpx;
		overflow-wrap: break-word;
		color: #949494;
		font-size: 25rpx;
	}
	.editButton {
		display: flex;
		align-items: center;
		justify-content: center;
		width: 40%;
		margin-left:30% ;
		border: #e0e0e0 solid 2rpx;
		border-radius: 20rpx;
	}
	.editIcon image{
		width: 27rpx;
		height: 27rpx;
		padding-right: 10rpx;
	}
	.editFont{
		font-size: 22rpx;
		color: #999999;
	}
	.tabbar{
		width: 60%;
		margin:20rpx 20% 0 20%;
		color: #ececec;
		font-size: 32rpx;
		display: flex;
		justify-content: space-around;
		align-items: center;
	}
	.unselectedItem {
		padding: 20rpx;
		color: #989898;
	}
	.selectedItem {
		color: #363636;
		padding: 20rpx;
		font-weight: 600;
	}
	.selectLine {
		height: 7rpx;
		width: 40rpx;
		border-radius: 10rpx;
		background-color: #1b72b1;
		position: relative;
		top: -10rpx;
		
		transition: 0.2s;
	}
	.zanDetail{
		height: 900rpx;
	}
	.shoucang{
		height:900rpx;
	}
	.tieDetail{
		height: 900rpx;
	}
	.normal {
		border-top: #9e9e9e solid 3rpx;

	}
	.tieItem{
		background-color: #ffffff;
		width: 100%;
		border-bottom: solid 1rpx #dddddd;
		display: flex;
	}
	.avatarBox{}
	.avatarBox image{
		width: 90rpx;
		height: 90rpx;
		margin: 20rpx;
	}
	.name_time{
		margin-top: 43rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding-right: 20rpx;
	}
	.name{
		font-size: 31rpx;
		color: #427eab;
		margin-right: 20rpx;
	}
	.time{
		font-size: 23rpx;
		color: #6e7082;
	}
	.content{
		margin-top: 30rpx;
		font-size: 30rpx;
		width: 70%;
		overflow: hidden;
		text-overflow: ellipsis;
		text-wrap: wrap;
		color: #292a2d;
		font-size: 30rpx;
		-webkit-box-orient: vertical;
		/* -webkit-line-clamp: 5; */
		min-height: 40rpx;
		max-height: 160rpx;
	}
	.table{
		width: 130rpx;
		margin-top: 10rpx;
		color: #0d469a;
		background-color: #b0c2e3;
		border-radius: 10rpx;
		padding-right: 10rpx;
		padding: 5rpx;
		font-size: 25rpx;
	}
	.buttons{
		margin-left: 300rpx;
		width: 300rpx;
		display: flex;
		justify-content: space-around;
	}
	.paiseBox{
		display: flex;
	}
	.paiseImgBox image{
		width: 30rpx;
		height: 30rpx;
		padding-right: 10rpx;
	}
	.paiseCount{
		font-size: 28rpx;
		color: #646464;
	}
	.paiseFont{
		font-size: 28rpx;
		color: #000000;
	}
	.commentsBox{
		display: flex;
	}
	.commentsImgBox image{
		width: 35rpx;
		height: 35rpx;
		padding-right: 10rpx;
	}
	.commentsCount{
		font-size: 28rpx;
		color: #000000;
	}
	.commentsFont{
		font-size: 28rpx;
		color: #000000;
	}
	.images{
		display: grid;
		grid-template-columns: repeat(2,1fr);
		grid-template-rows: 1;
		height: 200rpx;
		width: 540rpx;
		gap: -20rpx;
		overflow: hidden;
		margin-top: 10rpx;
	}
	.imageItem{
		/* margin-right: 30rpx; */
		height: 200rpx;
		width: 250rpx;
	}
	.imageItem image{
		height: 200rpx;
		width: 250rpx;
		border-radius: 20rpx;
	}
	
</style>
