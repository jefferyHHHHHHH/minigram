<script>
import { onMounted, getCurrentInstance } from 'vue';

export default {
	onLaunch(){
		
      const {
      		appContext: {
      			config: {
      				globalProperties: global
      		}
      			}
      	} = getCurrentInstance();
        console.log('app Launch');
        uni.getSystemInfo({
          success: function(e) {
			  console.log(e);
			  global.safeArea = e.safeArea;
            // #ifndef MP
            global.StatusBar = e.statusBarHeight;
            if (e.platform == 'android') {
              global.CustomBar = e.statusBarHeight + 50;
            } else {
              global.CustomBar = e.statusBarHeight + 45;
            }
            // #endif
            // #ifdef MP-WEIXIN
            global.StatusBar = e.statusBarHeight;
            let custom = wx.getMenuButtonBoundingClientRect();
            global.Custom = custom;
            global.CustomBar = custom.bottom + custom.top - e.statusBarHeight;
            // #endif        
            // #ifdef MP-ALIPAY
            global.StatusBar = e.statusBarHeight;
            global.CustomBar = e.statusBarHeight + e.titleBarHeight;
            // #endif
			console.log(global);
          },
        });
		
		
  },
  onShow() {
    console.log('app Show');

  },
  onHide() {
    console.log('app Hide');
  },
  globalData: {
  }
};

</script>

<style lang="scss">
	/*每个页面公共css */
	// @import '@/uni_modules/uni-scss/index.scss';
	// @import '@/static/customicons.css';
	// 设置整个项目的背景色
	page{
		background-color:#f7f7f7 ;
	}
	/* 主背景色或标题栏背景色 */
	// .main_bg_color{
	// 	background-color: #577da7;
	// }
	/* 次要背景色或卡片背景色 */
	// .miner_bg_color{
	// 	background-color: #7998b9;
	// }
	/* 页面背景色 */
	// .ym_bg_color{
	// 	background-color: #adc0d4;
	// }
	/* 组件背景色或内容区背景色 */
	// .zj_bg_color{
	// 	background-color: #c4d2e0;
	// }
	/* 导航栏背景色或主要按钮色 */
	// .main_bt_color{
	// 	background-color: #114783;
	// }
	/* 次要按钮色或强调色 */
	// .miner_bt_color{
	// 	background-color: #94acc4;
	// }
	/* 深色背景上的文本 */
	// .main_fontcolor{
	// 	color:#eef1f4 ;
	// }
	/* 次要文本色（用于浅色背景上的文本） */
	// .miner_fontcolor{
	// 	color: #44749c ;
	// }
	/* 分隔线或边框色 */
	// .line_color{
	// 	background-color:#3f6b9c ;
	// }
	/* 边框色或次要按钮边框色 */
	// .bian_color{
	// 	background-color:#9ab1cc ;
	// }
	/* 导航栏 */
	// .navigation-bar {
	//   background-color: #114783;
	//   color: #eef1f4;
	// }
	/* 卡片组件 */
	// .card {
	//   background-color: #7998b9;
	//   color: #eef1f4;
	//   border: 2rpx solid #3f6b9c;
	//   padding: 40rpx;
	//   margin: 20rpx;
	//   border-radius: 10rpx;
	// }
	/* 按钮 */
	// .button-primary {
	//   background-color: #114783;
	//   color: #eef1f4;
	//   padding: 20rpx;
	//   border: none;
	//   border-radius: 5rpx;
	//   margin: 20rpx 0;
	// }
	// .button-secondary {
	//   background-color: #94acc4;
	//   color: #eef1f4;
	//   padding: 20rpx;
	//   border: none;
	//   border-radius: 10rpx;
	//   margin: 20rpx 0;
	// }
</style>
