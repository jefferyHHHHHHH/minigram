<template>
	<view>
		<uni-nav-bar title="贴吧" statusBar='true' backgroundColor='#447db9' color='#eaebeb' fixed='true' left-icon="back" @clickLeft="navigateToBack" leftWidth='80'></uni-nav-bar>
		<view class="userInfo">
			<view @click="navigateToUserDetail('tiezi',tieId)"  class="avatar">
				<image      :src="authorAvatarUrl"></image>
			</view>
			<view class="name_time">
				<view class="name">{{authorNickname}}</view>
				<view class="time">{{postTimeAgo}}</view>
			</view>
		</view>
		<view class="content">
			{{postContent}}
		</view>
		<view class="imgs_videos">
			<view class="img_vdeoItem" v-if="videos && videos.length !== 0" v-for="(videoItem,index) in videos" :key="index">
				<video @fullscreenchange="fullscreenchange" @play="play" :ref="'video' + index" :src="videoItem" play-btn-position="center" controls></video>
			</view>
			<view class="img_vdeoItem" v-if="images && images.length !== 0" v-for="(imageItem,index) in images" :key="index">
				<image :src="imageItem"></image>
			</view>	
		</view>
		<view class="tablesBox">
			<view class="table" >
				<view class="tableFont">{{tag}}</view>
			</view>
		</view>	
		<view class="buttons">
				
				<view class="buttonBox">
					<view class="buttonIcon">
						<image v-if="!hasPaise" @click="toPaiseTie(tieId)" src="../../static/点赞 (4).png"></image>
						<image v-else  @click="toStopPaise(tieId)" src="../../static/点赞 (5).png"></image>
					</view>
					<view class="buttonFont">{{like_count}}</view>
				</view>
				
				<view class="buttonBox">
					<view class="buttonIcon">
						<image v-if="!hasStore" @click="toStore(tieId)" src="../../static/收藏.png"></image>
						<image v-else @click="toStopStore(tieId)" src="../../static/收藏 (1).png" ></image>
					</view>
					<view v-if="!hasStore" class="buttonFont">{{store_count}}</view>
					<view v-else class="buttonFont">取消</view>
				</view>
				
				<view class="buttonBox">
					<view class="buttonIcon">
						<image src="../../static/分享.png"></image>
						<button open-type="share" id="shareBtn"></button>
					</view>
					<view  class="buttonFont">分享</view>
				</view>
				
		</view>
		<view class="commentsCount">
			共 {{comments.length}} 条评论
		</view>
		<view class="commentsBox">
			<view v-for="(commentItem,index) in comments" :key="index" class="commentItem">
				<view @click="navigateToUserDetail('comment',commentItem.commentId)" class="commentAvatar">
					<image  :src="commentItem.commenterAvatarUrl"></image>
				</view>
				<view class="detailBox">
					<view class="name_tag_time_paise">
						<view class="name_tag_time">
							<view class="comName">{{commentItem.commenterNickname}} </view>
							<view class="tag" v-if="commentItem.identity">{{commentItem.identity}}</view>
							<view class="comTime"> · {{commentItem.timeAgo}}</view>
						</view>	
						<view class="commentPaiseIcon">
							<image v-if="commentItem.comHasPaise" @click="toStopPaiseComment(commentItem.commentId,index)" src="../../static/点赞 (5).png"></image>
							<image v-else  @click="toPaiseComment(commentItem.commentId,index)" src="../../static/点赞 (4).png"></image>
							<view style="{ color: commentItem.comHasPaise ? '#00bcd4' : '#9e9e9e'}" class="commentLikeCount">{{commentItem.comment_like_count}}</view>
						</view>
					</view>
					<view class="commentContent">{{commentItem.commentContent}}</view>
					<view class="aswerTitle">
						<view class="aswerCount" @click="viewSubComment(index)">共有 {{commentItem.subComments.length}} 条回复</view>
						<view class="rightArrow">
							<image src="../../static/前进.png"></image>
						</view>
					</view>
					<view v-if="commentItem.showSubComments">
						<view class="commentItem" v-for="(subCommentItem,subIndex) in commentItem.subComments" :key="index">
							<view @click="navigateToUserDetail('comment',subCommentItem.commentId)" class="commentAvatar">
								<image  :src="subCommentItem.commenterAvatarUrl"></image>
							</view>
							<view class="subDetailBox">
								<view class="sub_name_tag_time_paise">
									<view class="name_tag_time">
										<view class="comName">{{subCommentItem.commenterNickname}} </view>
										<view class="tag" v-if="subCommentItem.identity">{{subCommentItem.identity}}</view>
										<view class="comName" style="margin-left: 10rpx;">回复{{subCommentItem.replyName}} </view>
										<view class="comTime"> · {{subCommentItem.timeAgo}}</view>
									</view>	
									<view class="commentPaiseIcon">
										<image v-if="subCommentItem.comHasPaise" @click="toStopPaiseComment(subCommentItem.commentId,index,subIndex)" src="../../static/点赞 (5).png"></image>
										<image v-else   @click="toPaiseComment(subCommentItem.commentId,index,subIndex)" src="../../static/点赞 (4).png"></image>
										<view style="{ color: subCommentItem.comHasPaise ? '#00bcd4' : '#9e9e9e'}" class="commentLikeCount">{{subCommentItem.comment_like_count}}</view>
									</view>
								</view>
								<view class="commentContent">{{subCommentItem.commentContent}}</view>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script setup>
	import {onLoad,onReady,onShow,onUnload,onPageScroll,onShareAppMessage,onShareTimeline} from "@dcloudio/uni-app"
	import {ref,getCurrentInstance,inject} from 'vue'
	const {
		appContext:{
			config:{
				globalProperties:global
			}
		}
	} = getCurrentInstance();
	const refreshTokenGlobal = inject('refreshTokenGlobal');
	const tables = ['#吐槽爆料','#AI回答']
	var authorAvatarUrl = ref('')
	var authorNickname = ref('')
	var comments = ref([])
	var hasPaise = ref(false)
	var hasStore=ref(0)
	var images = ref([])
	var videos = ref([])
	var postContent = ref('')
	var postPublishTime = ref(0)
	var tag = ref('')
	var like_count = ref(0)
	var store_count =ref(0)
	var postTimeAgo = ref('')
	var tieId =-1
	function play(event) {
		let videoContext = uni.createVideoContext(event.target.id, this)
		videoContext.requestFullScreen()
	}
	//退出全屏时停止
	function fullscreenchange (event){
		if(!event.detail.fullScreen){
			const videoContext = uni.createVideoContext(event.target.id, this);
			videoContext.stop();
		}
	}
	function navigateToBack (){
		uni.navigateBack()
	}
	function getTieDetail (transTieId,hasRefresh=false){
		uni.getStorage({
			key:'tokens',
			success: (res) => {
				const refreshToken = res.data.refreshToken
				const accessToken = res.data.accessToken
				const Authorization =accessToken?'Bearer '+accessToken:''
				uni.request({
					url:'http://127.0.0.1:3007/user/showTieDetail',
					data:{
						tieId:transTieId
					},
					method:"GET",
					header:{'content-type': 'application/json',
								'Authorization': `${Authorization}`},
					success: (res) => {
						console.log(res)
						if(res.data.message=='jwt expired'){
							refreshTokenGlobal(refreshToken).then(()=>{
								if(hasRefresh==false){
									hasRefresh=true
									getTieDetail(transTieId,true)
								}else{
									console.log('refreshToken fail')
								}					
							}).catch((err)=>{
								console.log(err)
							})
						}else{
							 authorAvatarUrl.value = res.data.authorAvatarUrl
							 authorNickname.value = res.data.authorNickname
							 comments.value = res.data.comments
							 hasPaise.value = res.data.hasPaise
							 hasStore.value=res.data.hasStore
							 images.value = res.data.images
							 videos.value = res.data.videos
							 postContent.value = res.data.postContent 
							 postPublishTime.value = res.data.postPublishTime
							 tag.value = res.data.tag
							 like_count.value = res.data.like_count
							 store_count.value =res.data.store_count
							 postTimeAgo.value = res.data.postTimeAgo
							 tieId = transTieId
							 console.log(
							 authorAvatarUrl.value,
							 authorNickname.value,
							 comments.value,
							 'hasPaise:'+hasPaise.value,
							 hasStore.value,
							 images.value,
							 videos.value,
							 postContent.value,
							 postPublishTime.value,
							 tag.value,
							 like_count.value,
							 store_count.value,
							 postTimeAgo.value,)
						}			
					},
					fail: (err) => {
						console.log(err)
					}
				})
			}
		})
	}
	function viewSubComment(e){
		console.log(e)
		comments.value[e].showSubComments = true
		console.log(comments.value)
	}
	function toPaiseTie (acceptId,hasRefresh= false){
		console.log(acceptId)
		if(!global.isLogin.value){
			uni.showModal({
				title:'登录提示',
				content:'用户尚未登录，请先登录再进行操作，是非前往登录？',
				success:(res)=>{
					if(res.confirm){
						uni.navigateTo({
							url:'../../pages/login/login'
						})
					}else{
						if(res.cancel){
							return
						}
					}
					
				},
				fail: (err) => {
					return
				}
			})
		}else{
			const send_time = Date.now()
			const type = 'tiezi'
			uni.getStorage({
				key:'tokens',
				success: (res) => {
					const refreshToken = res.data.refreshToken
					const accessToken = res.data.accessToken
					uni.request({
						url:'http://127.0.0.1:3007/userPersonal/toPaise',
						method:'POST',
						data:{
							acceptId,
							send_time,
							type
						},
						header: {
						  'content-type': 'application/json',
						  'Authorization': 'Bearer '+accessToken
						},
						success: (res) => {
							console.log(res)
							if(res.data.message=='身份验证失败'){
								refreshTokenGlobal(refreshToken).then(()=>{
									if(hasRefresh==false){
										hasRefresh=true
										toPaise(acceptId,true)
									}else{
										console.log('refreshToken fail')
									}
									
								}).catch((err)=>{
									console.log(err)
								})
							}else{
								hasPaise.value =1
								like_count.value++
							}
							
						},
						fail: (err) => {
							console.log(err)
						}
					})
				}
			})
		}
		
		
	}
	function toStopPaise(acceptId,hasRefresh= false){
		if(!global.isLogin.value){
			uni.showModal({
				title:'登录提示',
				content:'用户尚未登录，请先登录再进行操作，是非前往登录？',
				success:(res)=>{
					if(res.confirm){
						uni.navigateTo({
							url:'../../pages/login/login'
						})
					}else{
						if(res.cancel){
							return
						}
					}
					
				},
				fail: (err) => {
					return
				}
			})
		}else{
			const type = 'tiezi'
			uni.getStorage({
				key:'tokens',
				success: (res) => {
					const refreshToken = res.data.refreshToken
					const accessToken = res.data.accessToken
					uni.request({
						url:'http://127.0.0.1:3007/userPersonal/toStopPaise',
						method:'POST',
						data:{
							acceptId,
							type
						},
						header: {
						  'content-type': 'application/json',
						  'Authorization': 'Bearer '+accessToken
						},
						success: (res) => {
							console.log(res)
							if(res.data.message=='身份验证失败'){
								refreshTokenGlobal(refreshToken).then(()=>{
									if(hasRefresh==false){
										hasRefresh=true
										toStopPaise(acceptId,index,true)
									}else{
										console.log('refreshToken fail')
									}
									
								}).catch((err)=>{
									console.log(err)
								})
							}else{
								hasPaise.value = 0
								like_count.value--
							}
							
						},
						fail: (err) => {
							console.log(err)
						}
					})
				}
			})
		}
	}
	function toStore(tieId,hasRefresh= false){
		if(!global.isLogin.value){
			uni.showModal({
				title:'登录提示',
				content:'用户尚未登录，请先登录再进行操作，是非前往登录？',
				success:(res)=>{
					if(res.confirm){
						uni.navigateTo({
							url:'../../pages/login/login'
						})
					}else{
						if(res.cancel){
							return
						}
					}
					
				},
				fail: (err) => {
					return
				}
			})
		}else{
			const store_time = Date.now()
			uni.getStorage({
				key:'tokens',
				success: (res) => {
					const refreshToken = res.data.refreshToken
					const accessToken = res.data.accessToken
					uni.request({
						url:'http://127.0.0.1:3007/userPersonal/toStore',
						method:'POST',
						data:{
							tieId,
							store_time
						},
						header: {
						  'content-type': 'application/json',
						  'Authorization': 'Bearer '+accessToken
						},
						success: (res) => {
							console.log(res)
							if(res.data.message=='身份验证失败'){
								refreshTokenGlobal(refreshToken).then(()=>{
									if(hasRefresh==false){
										hasRefresh=true
										toStore(tieId,index,hasRefresh)
									}else{
										console.log('refreshToken fail')
									}
									
								}).catch((err)=>{
									console.log(err)
								})
							}else{
								hasStore.value=1
								store_count.value++
							}
							
						},
						fail: (err) => {
							console.log(err)
						}
					})
				}
			})
		}
	}
	function toStopStore(tieId,index){
		if(!global.isLogin.value){
			uni.showModal({
				title:'登录提示',
				content:'用户尚未登录，请先登录再进行操作，是非前往登录？',
				success:(res)=>{
					if(res.confirm){
						uni.navigateTo({
							url:'../../pages/login/login'
						})
					}else{
						if(res.cancel){
							return
						}
					}
					
				},
				fail: (err) => {
					return
				}
			})
		}else{
			uni.getStorage({
				key:'tokens',
				success: (res) => {
					const refreshToken = res.data.refreshToken
					const accessToken = res.data.accessToken
					uni.request({
						url:'http://127.0.0.1:3007/userPersonal/toStopStore',
						method:'POST',
						data:{
							tieId
						},
						header: {
						  'content-type': 'application/json',
						  'Authorization': 'Bearer '+accessToken
						},
						success: (res) => {
							console.log(res)
							if(res.data.message=='身份验证失败'){
								refreshTokenGlobal(refreshToken).then(()=>{
									if(hasRefresh==false){
										hasRefresh=true
										toStore(tieId,index,hasRefresh)
									}else{
										console.log('refreshToken fail')
									}
									
								}).catch((err)=>{
									console.log(err)
								})
							}else{
								hasStore.value=0
								store_count.value--
							}
						},
						fail: (err) => {
							console.log(err)
						}
					})
				}
			})
		}
	}
	function toPaiseComment(acceptId,rootIndex,sonIndex=-1,hasRefresh= false){
		console.log(acceptId)
		if(!global.isLogin.value){
			uni.showModal({
				title:'登录提示',
				content:'用户尚未登录，请先登录再进行操作，是非前往登录？',
				success:(res)=>{
					if(res.confirm){
						uni.navigateTo({
							url:'../../pages/login/login'
						})
					}else{
						if(res.cancel){
							return
						}
					}
					
				},
				fail: (err) => {
					return
				}
			})
		}else{
			const send_time = Date.now()
			const type = 'comment'
			uni.getStorage({
				key:'tokens',
				success: (res) => {
					const refreshToken = res.data.refreshToken
					const accessToken = res.data.accessToken
					uni.request({
						url:'http://127.0.0.1:3007/userPersonal/toPaise',
						method:'POST',
						data:{
							acceptId,
							send_time,
							type
						},
						header: {
						  'content-type': 'application/json',
						  'Authorization': 'Bearer '+accessToken
						},
						success: (res) => {
							console.log(res)
							if(res.data.message=='身份验证失败'){
								refreshTokenGlobal(refreshToken).then(()=>{
									if(hasRefresh==false){
										hasRefresh=true
										toPaise(acceptId,true)
									}else{
										console.log('refreshToken fail')
									}
									
								}).catch((err)=>{
									console.log(err)
								})
							}else{
								console.log(comments,rootIndex,sonIndex)
								if(sonIndex==-1){
									comments.value[rootIndex].comHasPaise =1
									comments.value[rootIndex].comment_like_count++
								}else{
									comments.value[rootIndex].subComments[sonIndex].comHasPaise = 1
									comments.value[rootIndex].subComments[sonIndex].comment_like_count++
								}
							}
							
						},
						fail: (err) => {
							console.log(err)
						}
					})
				}
			})
		}
		
		
	}
	function toStopPaiseComment(acceptId,rootIndex,sonIndex=-1,hasRefresh= false){
		console.log(acceptId)
		if(!global.isLogin.value){
			uni.showModal({
				title:'登录提示',
				content:'用户尚未登录，请先登录再进行操作，是非前往登录？',
				success:(res)=>{
					if(res.confirm){
						uni.navigateTo({
							url:'../../pages/login/login'
						})
					}else{
						if(res.cancel){
							return
						}
					}
					
				},
				fail: (err) => {
					return
				}
			})
		}else{
			const type = 'comment'
			uni.getStorage({
				key:'tokens',
				success: (res) => {
					const refreshToken = res.data.refreshToken
					const accessToken = res.data.accessToken
					console.log(acceptId)
					uni.request({
						url:'http://127.0.0.1:3007/userPersonal/toStopPaise',
						method:'POST',
						data:{
							acceptId,
							type
						},
						header: {
						  'content-type': 'application/json',
						  'Authorization': 'Bearer '+accessToken
						},
						success: (res) => {
							console.log(res)
							if(res.data.message=='身份验证失败'){
								refreshTokenGlobal(refreshToken).then(()=>{
									if(hasRefresh==false){
										hasRefresh=true
										toPaise(acceptId,true)
									}else{
										console.log('refreshToken fail')
									}
									
								}).catch((err)=>{
									console.log(err)
								})
							}else{
								console.log(comments,rootIndex,sonIndex)
								if(sonIndex==-1){
									comments.value[rootIndex].comHasPaise =0
									comments.value[rootIndex].comment_like_count--
								}else{
									comments.value[rootIndex].subComments[sonIndex].comHasPaise = 0
									comments.value[rootIndex].subComments[sonIndex].comment_like_count--
								}
							}
							
						},
						fail: (err) => {
							console.log(err)
						}
					})
				}
			})
		}
		
		
	}
	function navigateToUserDetail(type,id){
		console.log(type,id)
		uni.navigateTo({
			url:`../userIndex/userIndex?type=${type}&id=${id}`
		})
	}
	onShareAppMessage((res)=>{
		return {
			title: `${authorNickname.value}发布的帖子`,
			path: '/tieBaPages/tieDetail/tieDetail',
			imageUrl: authorAvatarUrl
		}
	})
	onShareTimeline((res)=>{
		return {
			title: `${authorNickname.value}发布的帖子`,
			path: '/tieBaPages/tieDetail/tieDetail',
			imageUrl: authorAvatarUrl
		}
	})
	onLoad((e)=>{
		getTieDetail(e.tieId,false)
		console.log(global.isLogin)
		uni.request({
			url:'http://127.0.0.1:3007/user/viewCountAdd',
			method:'GET',
			data:{
				tieId:e.tieId
			},
			success: (res) => {
				console.log(res)
			}
		})
	})
</script>

<style>
	.userInfo{
		background-color: #ffffff;
		display: flex;
		padding: 30rpx;
		align-items: center;
	}
	.avatar{}
	.avatar image{
		width: 100rpx;
		height: 100rpx;
		border-radius: 80rpx;
	}
	.name_time{
		margin-left: 20rpx;
	}
	.name{
		font-size: 30rpx;
		color: black;
		font-weight: 600;
	}
	.time{
		margin-top: 10rpx;
		font-size: 24rpx;
		color: #a6a6a6;
	}
	.content{
		background-color: #ffffff;
		padding: 0 30rpx 30rpx;
		font-size: 33rpx;
		color: #383838;
		line-height: 40rpx;
		letter-spacing: 3rpx;
	}
	.table{
		margin-left: 20rpx;
		background-color: #e2f0ff;
		padding: 15rpx;
		min-width: 50rpx;
		max-width: 140rpx;
		padding: 10rpx;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.tableFont{
		color: #576070;
		font-size: 24rpx;
	}
	.buttons{
		background-color: #ffffff;
		display: flex;
		align-items: center;
		padding-top: 25rpx;
		padding-left: 310rpx;
	}
	.buttonBox{
		display: flex;
		margin-left: 50rpx;
	}
	.buttonIcon{}
	.buttonIcon image{
		width: 45rpx;
		height: 45rpx;
	}
	.buttonIcon image:last-of-type{
		width: 36rpx;
		height: 36rpx;
	}
	.buttonFont{
		font-size: 25rpx;
		color:#9d9d9d ;
		margin-left: 10rpx;
	}
	.tablesBox {
		display: flex;
		padding-left: 30rpx;
		background-color: #ffffff;
	}
	.imgs_videos{
		display: flex;
		padding: 30rpx;
		background-color: #ffffff;
		flex-wrap: wrap;
		justify-content: flex-start;
		align-items: center;
	}
	.img_vdeoItem video{
		width: 220rpx;
		height: 220rpx;
	}
	.img_vdeoItem image{
		width: 220rpx;
		height: 220rpx;
	}
	.img_videoItem{
		margin-left: 20rpx;
	}
	.commentsCount{
		font-size: 27rpx;
		color: #4c5462;
		margin:30rpx ;
	}
	.commentAvatar image{
		width: 70rpx;
		height: 70rpx;
		border-radius: 70rpx;
		
	}
	.commentPaiseIcon image{
		width: 40rpx;
		height: 40rpx;
	}
	.rightArrow{
		width: 40rpx;
		height: 40rpx;
	}
	.name_tag_time_paise{
		display: flex;
		justify-content: space-between;
		align-items: center;
		width:580rpx ;
	}
	.name_tag_time{
		display: flex;
		align-items: center;
	}
	.commentItem{
		display: flex;
		padding: 0rpx 30rpx 0rpx 30rpx;
		width: calc(80%);
		
	}
	.detailBox{
		padding: 0rpx 20rpx 10rpx 20rpx;
	}
	.comTime{
		font-size: 24rpx;
		color: #a6a6a6;
		margin-left: 10rpx;
	}
	.comName{
		font-size: 26rpx;
		color: #5b5b5b;
		font-weight: 600rpx;
	}
	.commentContent {
		padding: 10rpx 0 20rpx 0;
		width: 530rpx;
		font-size: 29rpx;
		letter-spacing: 3rpx;
		line-height: 35rpx;
	}
	.aswerCount {
		font-size: 27rpx;
		color: #415376;
		margin-bottom: 10rpx;
	}
	.rightArrow image{
		width: 30rpx;
		height: 30rpx;
		padding-bottom: 2rpx;
	}
	.rightArrow {
		margin-left: 10rpx;
	}
	.aswerTitle{
		display: flex;
		align-items: center;
	}
	.tag{
		font-size: 25rpx;
		color: #e2f0ff;
		background-color: #5e6eff;
		border-radius: 10rpx;
		width: max-content;
	}
	.subDetailBox {
		padding: 0rpx 20rpx 0rpx 20rpx;
	}
	.sub_name_tag_time_paise{
		display: flex;
		justify-content: space-between;
		align-items: center;
		width:460rpx ;
	}
	.commentLikeCount {
		position: relative;
		left: 14rpx;
		top: 0rpx;
		font-size: 25rpx;
		color: #9e9e9e;
	}
	#shareBtn {
		position: absolute;
		opacity: 0;
		width: 80rpx;
		height: 39rpx;
		top: 550rpx;
		right: 50rpx;
	}
</style>
