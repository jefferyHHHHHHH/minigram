<template>
	<view>
		<uni-nav-bar title="贴吧" statusBar='true' backgroundColor='#447db9' color='#eaebeb' fixed='true' left-icon="back" @clickLeft="navigateToBack" leftWidth='80'></uni-nav-bar>
		<uni-drawer ref="showRight" mode="right" :mask-click="false">
			<scroll-view class="dreawer" style="height: 100%;"  scroll-y="true">
				<view class="areaTitle" :style="{paddingTop:statusBar}">
					板块选择
				</view>
				<view v-for="(areaItem,areaIndex) in areas" @click="chooseTag(areaIndex)" class="areaItem"  :key="areaItem">{{areaItem}}</view>
			</scroll-view>
		</uni-drawer>
		<view class="tagArea">
			<view class="textArea" @click="showArea">
				<view class="gongicon_font">
					<view class="gongIcon">
						<image src="../../static/_text_align_justify.png"></image>
					</view>
					<view class="areaFont">选择板块</view>
				</view>
				<view class="rightArrow">
					<image src="../../static/前进.png"></image>
				</view>
			</view>
			<view v-if="tag" class="chosenTag">
				<view class="tagContent">{{tag}}</view>
			</view>
		</view>	
		
		
		<view class="editArea">
			<view class="fontArea">
				<textarea @input="writeContent" placeholder="在此处输入正文"></textarea>
			</view>
			<view class="piture_video">
				<view class="kuang" v-for="(imageItem,index) in imageArray">
					<image :src="imageItem" class="uploadImgs" @click="previewImage(imageArray,index)"></image>
					<view class="delete-badge" @click="deleteImage(index)">
						<view>×</view>
					</view>
				</view>
				<view class="kuang" v-for="(videoItem,index) in videoArray" @click="foreseeVideo">
					<video :src="videoArray" ></video>
					<view class="delete-badge" @click="deleteVideo(index)">
						<view>×</view>
					</view>
				</view>
				<view class="kuang" @click="chooseImage">
					<view class="kuangIcon">
						<image src="../../static/图片.png"></image>
					</view>
					<view class="kuangFont" id="imageIcon">添加图片</view>
				</view>
				<view class="kuang" @click="chooseVideo">
					<view class="kuangIcon">
						<image src="../../static/视频.png" id="videoIcon"></image>
					</view>
					<view class="kuangFont">添加视频</view>
				</view>
			</view>
		</view>
		
		<button class="publishButton" @click="finishPublish">发布</button>
	</view>
</template>

<script setup>
	import {onLoad} from "@dcloudio/uni-app"
	import {ref,getCurrentInstance} from 'vue'
	const instance = getCurrentInstance()
	var imageArray = ref([])
	var videoArray = ref([])
	var lotm_images =[]
	var lotm_videos =[]
	var content = ref('')
	var tags = ref('')
	var tieInfo ={}
	var tag =ref('')
	const areas = ['取消选择','#身边趣事','#创作分享','#吐槽爆料','#时事新闻','#情感','#桂电有嘻哈','#电子游戏','#学业疑难','#日常生活','#寻物招领','#血液顾问','#全职','#实习','#短期兼职','#推荐岗位','#免费赠送','#鞋服包饰','#美妆护肤','#书籍资料','#电子数码','#生活百货','#电器家具','#食品材料','#运动健身','#票卡服务','#租房合租']
	const {
		appContext:{
			config:{
				globalProperties:global
			}
		}
	} = getCurrentInstance();
	console.log(global,global.Custom.bottom,global.Custom.height*2);
	const navBarHeight = global.Custom.bottom*2+15+"rpx";
	const LeftArrowTop = global.Custom.bottom*2-60+"rpx";
	const statusBar= global.StatusBar*2+'rpx';
	
	onLoad(()=>{
		uniCloud.init({
			env:'mp-921310a0-d0c7-4dc6-953b-3e8562e454fa',
			provider:"aliyun",
			spaceId:'mp-921310a0-d0c7-4dc6-953b-3e8562e454fa',
			clientSecret:'KYdsmMe9L9NIjqe/INkHGg=='
		})
	})
	function deleteImage(index){
		imageArray.value.splice(index,1)
	}
	function deleteVideo(index){
		videoArray.value.splice(index,1)
	}
	function previewImage(images,index){
		console.log(images,index)
		let imgs = images
		uni.previewImage({
			current:index,
			urls:imgs
		})
		
	}
	function navigateToBack (){
		uni.navigateBack()
	}
	function chooseImage(){
		uni.chooseImage({
			success: (e) => {
				console.log(e)
				imageArray.value = [...imageArray.value,e.tempFilePaths[0]]
				console.log(imageArray.value)
			},
			fail: (err) => {
				console.log(err)
			}
		})
	}
	function chooseVideo(){
		uni.chooseVideo({
			success: (e) => {
				console.log(e)
				videoArray.value =[...videoArray.value,e.tempFilePath]
				console.log(videoArray.value)
			},
			fail: (err) => {
				console.log(err)
			}
		})
	}
	// function imagesUpload(){
	// 	imageArray.value.forEach((imageItem,index)=>{
	// 		uniCloud.uploadFile({
	// 			url:'https://file-uniclgtrxf-mp-921310a0-d0c7-4dc6-953b-3e8562e454fa.oss-cn-zhangjiakou.aliyuncs.com',
	// 			filePath:imageItem,
	// 			cloudPath:'tiezi/images/'+imageItem.replace(/^(https?:\/\/)?\/?/i, ''),
	// 			success: (e) => {
	// 				console.log(e)
	// 				lotm_images = [...lotm_images,e.filePath]
	// 				if(lotm_images.length==imageArray.value.length){
						
	// 				}
	// 			},
	// 			fail: (err) => {
	// 				console.log(err)
	// 			},
	// 			complete: () => {
					
	// 			}
	// 		})
	// 	})
	// }
	// function videosUpload(){
	// 	videoArray.value.forEach((videoItem,videoIndex)=>{
	// 		uniCloud.uploadFile({
	// 			url:'https://file-uniclgtrxf-mp-921310a0-d0c7-4dc6-953b-3e8562e454fa.oss-cn-zhangjiakou.aliyuncs.com',
	// 			filePath:videoItem,
	// 			cloudPath:'tiezi/videos/'+videoItem.replace(/^(https?:\/\/)?\/?/i, ''),
	// 			success: (e) => {
	// 				console.log(e)
	// 				lotm_videos = [...lotm_videos,{filePath:e.filePath,fileId:e.fileId}]
	// 			},
	// 			fail: (err) => {
	// 				console.log(err)
	// 			}
	// 		})
		
	// 	})
	// }
	async function imagesUpload() {
	    for (const imageItem of imageArray.value) {
	        try {
	            const e = await uniCloud.uploadFile({
	                url: 'https://file-uniclgtrxf-mp-921310a0-d0c7-4dc6-953b-3e8562e454fa.oss-cn-zhangjiakou.aliyuncs.com',
	                filePath: imageItem,
	                cloudPath: 'tiezi/images/' + imageItem.replace(/^(https?:\/\/)?\/?/i, ''),
	            });
	            console.log(e);
	            lotm_images = [...lotm_images, e.filePath];
	        } catch (err) {
	            console.log(err);
	        }
	    }
	}
	
	async function videosUpload() {
	    for (const videoItem of videoArray.value) {
	        try {
	            const e = await uniCloud.uploadFile({
	                url: 'https://file-uniclgtrxf-mp-921310a0-d0c7-4dc6-953b-3e8562e454fa.oss-cn-zhangjiakou.aliyuncs.com',
	                filePath: videoItem,
	                cloudPath: 'tiezi/videos/' + videoItem.replace(/^(https?:\/\/)?\/?/i, ''),
	            });
	            console.log(e);
	            lotm_videos = [...lotm_videos, { filePath: e.filePath, fileId: e.fileId }];
	        } catch (err) {
	            console.log(err);
	        }
	    }
	}
	function writeContent(e){
		console.log(e)
		content = e.detail.value
		console.log(content)
	}
	function chooseTag(areaIndex){
		console.log(areaIndex)
		if(areaIndex==0){
			tag.value = ''
			instance.refs.showRight.close();
			return
		}
		tag.value = areas[areaIndex]
		console.log(tag)
		instance.refs.showRight.close();
	}
	
	async function finishPublish() {
		uni.showLoading({
			mask:true,
			title:'正在上传中。。。'
		})
	  if (imageArray.value.length !== 0) {
	    await imagesUpload();
	  }
	  if (videoArray.value.length !== 0) {
	    await videosUpload();
	  }
	  uni.getStorage({
	    key: 'tokens',
	    success: (res) => {
			const refreshToken = res.data.refreshToken
			const accessToken = res.data.accessToken
	        const publish_time = Date.now();
	        const tieInfo = {
	        publish_time,
	        content: content,
	        view_count: 0,
	        tag: tag.value,
	        images: lotm_images,
	        videos: lotm_videos
	      };
	      console.log(res);
	      uni.request({
	        url: 'http://127.0.0.1:3007/userPersonal/tieziPublish',
	        data: {
	          tieInfo: tieInfo
	        },
	        method: 'POST',
	        header: {
	          'content-type': 'application/json',
	          'Authorization': 'Bearer '+accessToken
	        }
	      }).then((response) => {
			  console.log(response)
			  if(response.data.message=='身份验证失败'){
					console.log(refreshToken)
					uni.request({
						url:'http://127.0.0.1:3007/user/refreshtoken',
							data:{
								refreshToken:refreshToken
							},
							method:	'GET'
							}).then((res)=>{
								console.log(res)
								if(res.data.status==1){
									uni.showToast({
										icon:"none",
										title:'token失效，请重新登录！'
									})
									uni.navigateTo({
										url:'../../pages/login/login'
									})
									return
								}
								if(res.data.data.accessToken&&res.data.data.refreshToken){
									const tokens = res.data.data
									uni.setStorage({
										key:'tokens',
										data:tokens,
										success: (res) => {
											console.log(res)
											finishPublish()										
										},
										fail: (err) => {
											console.log(err)
										}
									})
								}
								
							}) .catch((err)=>{
								console.log(err)
			  	})
			  }else{
				  imageArray.value=[]
				  videoArray.value=[]
				  lotm_images=[]
				  lotm_videos=[]
				  uni.hideLoading()
				  uni.showToast({
				  	icon:"none",
					title:'帖子发布成功'
				  }).then(()=>{
					  setTimeout(()=>{
						  uni.switchTab({
						  	url:'../../pages/tieBa/tieBa'
						  })
					  },1000)
					  
				  })
				  
			  }
			  
	      }).catch((error) => {
			  console.log(error)
	      });
	    },
	    fail: (err) => {
	      console.log('fail',err);
		  uni.showToast({
		  	icon:"none",
			title:'token不见了。。重新登录吧'
		  })
		  uni.navigateTo({
		  	url:'../../pages/login/login'
		  })
	    }
	  });
	}	
		
	function showArea(){
		instance.refs.showRight.open();
	}
	function hideArea(){
		instance.refs.showRight.close();
	}
</script>
<style>
	.tagArea{
		background-color: #ffffff;
		border-bottom: solid 1rpx #f0f0f0;
		padding: 30rpx 20rpx;
	}
	.textArea{
		display: flex;
		justify-content: space-between;
		align-items: center;
		}
	.gongicon_font{
		display: flex;
	}
	.chosenTag {
		margin-left: 20rpx;
		padding: 16rpx 0 0 0;
	}
	.tagContent{
		width: max-content;
		font-size: 28rpx;
		padding: 10rpx;
		border-radius: 10rpx;
		background-color: #447db9;
		color: #ffffff;
	}
	.gongIcon{}
	.gongIcon image{
		height: 40rpx;
		width: 40rpx;
	}
	.areaFont{
		font-size: 28rpx;
		color: black;
		font-weight: 600;
		padding-left: 20rpx;
		/* border-left: #447db9 10rpx solid; */
		
	}
	.rightArrow{}
	.rightArrow image{
		height: 30rpx;
		width: 30rpx;
	}
	.editArea{
		padding: 25rpx 20rpx;
		background-color: #ffffff;
		min-height: 700rpx;
		width: 100%;
		padding-bottom: 40rpx;
		border-bottom: solid 1rpx #f0f0f0;
	}
	.fontArea{
		height: 500rpx;
		width: calc(100%-40rpx);
		margin-left: 20rpx;
	}
	.piture_video{
		display: flex;
		flex-wrap: wrap;
	}
	.kuang{
		position: relative;
		width: 220rpx;
		height: 210rpx;
		margin-left: 15rpx;
		background-color: #dce0e6;
		display: flex;
		justify-content: center;
		align-items: center;
		flex-direction: column;
		border-radius: 20rpx;
		margin-bottom: 15rpx;
	}
	.kuang image {
		width: 220rpx;
		height: 210rpx;
		/* border-radius: 20rpx; */
	}
	.kuang video{
		width: 220rpx;
		height: 210rpx;
		border-radius: ;
	}
	.kuangIcon image{
		width: 40rpx;
		height: 40rpx;
	}
	.kuangFont{
		font-size: 23rpx;
		color: #787878;
	}
	.delete-badge {
	  position: absolute;
	  top: 0;
	  right: 0;
	  background-color: rgba(255, 0, 0, 0.8); /* 红色背景，半透明 */
	  color: white;
	  width: 20px;
	  height: 20px;
	  display: flex;
	  align-items: center;
	  justify-content: center;
	  border-radius: 100%;
	}
	.delete-badge view{
		padding-bottom: 5rpx;
	}
	.publishButton{
		margin-top: 20rpx;
		background-color:#447db9;
		color: #ffffff;
		width: 90%;
		margin-left: 5%;
		border-radius: 50rpx;
	}
	.areaTitle{
		color: #ffffff;
		font-size: 32rpx;
		font-weight: 600;
		background-color: #447db9;
		padding: 10rpx;
	}
	.areaItem{
		padding: 15rpx;
		font-size: 29rpx;
		background-color: #ffffff;
		margin-top: 10rpx;
	}
	.dreawer {
		background-color: #f7f7f7;
	}
	.uploadImgs {
		width: 220rpx;
		height: 210rpx;
		border-radius: 20rpx;
	}
</style>
