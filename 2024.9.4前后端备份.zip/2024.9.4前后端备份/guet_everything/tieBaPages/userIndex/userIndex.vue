<template>
	<view>
		<view class="nav-bar" :style="{height:navBarHeight,opacity:navBarOpacity}"></view>	
		<view class="leftArrow" :style="{top:LeftArrowTop}" @click="navigateBack">
			<image src="../../static/左箭头.png"></image>
		</view>
		<view class="navBarTitle" :style="{top:LeftArrowTop}">个人主页</view>
		
		<view class="topBox" :class="isFixed?'fixedTopBox':''">
			<!-- <image src="../../static/backgroundIMG.png"></image> -->
		</view>
		<view class="infoBox">
			<view class="avaNamBox">
				<view class="userAvatarBox">
					<image  :src="avatarUrl"></image>
				</view>
				<view class="name_fen_guan_fred">
					<view class="focusButton_name">
							<view class="name">{{nickname}}</view>
							<view v-if="hasFocus"  class="selectedButton" @click="toCancelFocus(id,type)">已关注</view>
							<view v-else class="focusButton" @click="toFocus(id,type)">关注</view>
					</view>
					
					<view class="fen_guan_fred">
						<view class="countUp">
							<view class="count">20</view>
							<view class="countTitle">粉丝</view>
						</view>
						<view class="countUp">
							<view class="count">15</view>
							<view class="countTitle">关注</view>
						</view>
						<view class="countUp">
							<view class="count">2</view>
							<view class="countTitle">朋友</view>
						</view>
					</view>
				</view>
			</view>	
			<view class="jianjie">
				{{jianjie}}
			</view>
			
			<view class="editButton" v-if="isYourself">
				<view class="editIcon">
					<image src="../../static/编辑.png"></image>
				</view>
				<view class="editFont">
					编辑个人资料
				</view>
			</view>
			
			<view class="tabbar">
				<view :class="[selected==1?'selectedItem':'unselectedItem']" @click="changeSelect(1)">攒局</view>
				<view :class="[selected==2?'selectedItem':'unselectedItem']" @click="changeSelect(2)">帖子</view>
				<view :class="[selected==3?'selectedItem':'unselectedItem']" @click="changeSelect(3)">收藏</view>
			</view>
			<view class="selectLine" :style="{left:lineLeft}" data-=""></view>
			
			<view v-if="selected==1" class="zanDetail normal">
				lalala
			</view>
			
			<view v-if="selected==2" class="tieDetail normal">
				<view class="tieItem" v-for="(tieItem,index) in tieArray" :key="index">
					<view class="avatarBox">
						<image @click.stop="navigateToUserInfo" :src="avatarUrl" ></image>
					</view>
					<view class="infoBox" @click="navigateToDetail(tieItem.tieId)">
						<view class="name_time">
							<view class="name" @click.stop="navigateToUserInfo">{{nickname}}</view>
							<view class="time">{{tieItem.timeAgo}}</view>
						</view>
						<view class="content">{{tieItem.content}}</view>
						<view class="images" v-if="tieItem.images!==null">
							<view class="imageItem" v-for="(imageItem,imageIndex) in tieItem.images"     key="imageIndex">
								<image  @click.stop="previewImage(tieItem.images,imageIndex)" mode="aspectFill" :src="imageItem"></image>
							</view>
						</view>	
						<view class="table">{{tieItem.tag}}</view>
						<view class="buttons">
							<view class="paiseBox">
								<view class="paiseImgBox">
									<image @click.stop="toStopPaise(tieItem.tieId,index)" v-if="tieItem.hasPaise==1" src="../../static/点赞 (3).png"></image>
									<image @click.stop="toPaise(tieItem.tieId,index)" v-if="!tieItem.hasPaise==1" src="../../static/点赞 (2).png"></image>
								</view>
								<view class="paiseCount" >{{tieItem.like_count}}</view>
							</view>
							<view class="paiseBox">
								<view class="paiseImgBox">
									<image @click.stop ="toStopStore(tieItem.tieId,index)" v-if="tieItem.hasStore==1" src="../../static/收藏_fill.png"></image>
									<image @click.stop ="toStore(tieItem.tieId,index)" v-if="!tieItem.hasStore==1" src="../../static/收藏.png"></image>
								</view>
								<view class="paiseCount" >{{tieItem.store_count}}</view>
							</view>
							<view class="commentsBox">
								<view class="commentsImgBox">
									<image @click.stop="toComment" src="../../static/评论 (1).png" ></image>
								</view>
								<view class="commentsCount" >{{tieItem.comment_count}}</view>
							</view>
						</view>
					</view>
				</view>
			</view>
			
			<view v-if="selected==3" class="shoucang normal">
				<view class="tieItem" v-for="(tieItem,index) in storeArray" :key="index">
					<view class="avatarBox">
						<image @click.stop="navigateToUserInfo" :src="avatarUrl" ></image>
					</view>
					<view class="infoBox" @click="navigateToDetail(tieItem.tieId)">
						<view class="name_time">
							<view class="name" @click.stop="navigateToUserInfo">{{nickname}}</view>
							<view class="time">{{tieItem.timeAgo}}</view>
						</view>
						<view class="content">{{tieItem.content}}</view>
						<view class="images" v-if="tieItem.images!==null">
							<view class="imageItem" v-for="(imageItem,imageIndex) in tieItem.images"     key="imageIndex">
								<image  @click.stop="previewImage(tieItem.images,imageIndex)" mode="aspectFill" :src="imageItem"></image>
							</view>
						</view>	
						<view class="table">{{tieItem.tag}}</view>
						<view class="buttons">
							<view class="paiseBox">
								<view class="paiseImgBox">
									<image @click.stop="toStopPaise(tieItem.tieId,index)" v-if="tieItem.hasPaise==1" src="../../static/点赞 (3).png"></image>
									<image @click.stop="toPaise(tieItem.tieId,index)" v-if="!tieItem.hasPaise==1" src="../../static/点赞 (2).png"></image>
								</view>
								<view class="paiseCount" >{{tieItem.like_count}}</view>
							</view>
							<view class="paiseBox">
								<view class="paiseImgBox">
									<image @click.stop ="toStopStore(tieItem.tieId,index)" v-if="tieItem.hasStore==1" src="../../static/收藏_fill.png"></image>
									<image @click.stop ="toStore(tieItem.tieId,index)" v-if="!tieItem.hasStore==1" src="../../static/收藏.png"></image>
								</view>
								<view class="paiseCount" >{{tieItem.store_count}}</view>
							</view>
							<view class="commentsBox">
								<view class="commentsImgBox">
									<image @click.stop="toComment" src="../../static/评论 (1).png" ></image>
								</view>
								<view class="commentsCount" >{{tieItem.comment_count}}</view>
							</view>
						</view>
					</view>
				</view>
			</view>
			
		</view>
	</view>
	<view class="bottom"></view>
</template>

<script setup>
	import {onLoad,onReady,onShow,onUnload,onPageScroll} from "@dcloudio/uni-app"
	import { getCurrentInstance,ref,computed,inject } from 'vue';
	const {
		appContext:{
			config:{
				globalProperties:global
			}
		}
	} = getCurrentInstance();
	const refreshTokenGlobal = inject('refreshTokenGlobal');
	const showLoginTip = inject('showLoginTip')
	console.log(global,global.Custom.bottom,global.Custom.height*2);
	const navBarHeight = global.Custom.bottom*2+15+"rpx";
	const LeftArrowTop = global.Custom.bottom*2-60+"rpx";
	console.log(navBarHeight,LeftArrowTop)
	var scrollTop = ref(0);
	var navBarOpacity = computed(()=>{
		if(scrollTop.value >100){
			return 1;
		}else{
			return scrollTop.value/100;
		}
	})
	var navBarFontOpacity = computed(()=>{
		return 1-navBarOpacity
	})
	var isFixed = computed(()=>{
		if(scrollTop.value>=240){
			return true;
		}else {
			return false;
		}
	})
	const scrollHeight = computed(()=>{
		return global.safeArea.bottom*2+"rpx";
	})
	var isYourself = ref(false)
	
	const jianjie = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	console.log(scrollHeight,global.safeArea)
	var selected = ref(2);
	var lineLeft =computed(()=>{
		switch (selected.value){
			case 1:return '206rpx'
				break;
			case 2:return '356rpx'
				break;
			case 3:return '506rpx'
			default:return '356rpx'
				break;
		}
	})
	var avatarUrl = ref('https://thirdwx.qlogo.cn/mmopen/vi_32/POgEwh4mIHO4nibH0KlMECNjjGxQUq24ZEaGT4poC6icRiccVGKSyXwibcPq4BWmiaIGuG1icwxaQX6grC9VemZoJ8rg/132')
	var nickname = ref('未知姓名')
	var major = ref('未知专业')
	var gender = ref('')
	var shortIntroduce = ref('')
	var tieArray = ref([])
	var storeArray = ref([])
	var hasGetStoreArray = ref(false)
	var teamArray = ref([])
	var id = ref('')
	var type = ref('')
	var hasFocus = ref(false)
	function navigateBack(){
		uni.navigateBack()
	}
	function changeSelect(e){
		if(e==selected.value){
			return;
		}else{
			selected.value=e;
			
			
		}
		if(e===3&&hasGetStoreArray.value===false){
			hasGetStoreArray.value =true
			viewStoreList()
		}
	}
	function viewStoreList(){
		if(!global.isLogin.value){
			uni.showModal({
				title:'登录提示',
				content:'用户尚未登录，请先登录再进行操作，是非前往登录？',
				success:(res)=>{
					if(res.confirm){
						uni.navigateTo({
							url:'../../pages/login/login'
						})
					}else{
						if(res.cancel){
							return
						}
					}
					
				},
				fail: (err) => {
					return
				}
			})
		}else{
			const send_time = Date.now()
			uni.getStorage({
				key:'tokens',
				success: (res) => {
					const refreshToken = res.data.refreshToken
					const accessToken = res.data.accessToken
					uni.request({
						url:`http://127.0.0.1:3007/userPersonal//showStoreList`,
						method:'GET',
						data:{
							id:id.value,
							type:type.value
						},
						header: {
						  'content-type': 'application/json',
						  'Authorization': 'Bearer '+accessToken
						},
						success: (res) => {
							console.log(res)
							if(res.data.message=='身份验证失败'){
								refreshTokenGlobal(refreshToken).then(()=>{
									if(hasRefresh==false){
										hasRefresh=true
										getUserInfoNTieArray(id,type,true)
									}else{
										console.log('refreshToken fail')
									}
									
								}).catch((err)=>{
									console.log(err)
								})
							}else{
								storeArray.value = res.data
							}
							
						},
						fail: (err) => {
							console.log(err)
						}
					})
				}
			})
		}
	}
	function getUserInfoNTieArray(id,type,hasRefresh= false){
		if(!global.isLogin.value){
			uni.showModal({
				title:'登录提示',
				content:'用户尚未登录，请先登录再进行操作，是非前往登录？',
				success:(res)=>{
					if(res.confirm){
						uni.navigateTo({
							url:'../../pages/login/login'
						})
					}else{
						if(res.cancel){
							return
						}
					}
					
				},
				fail: (err) => {
					return
				}
			})
		}else{
			const send_time = Date.now()
			const type = 'tiezi'
			uni.getStorage({
				key:'tokens',
				success: (res) => {
					const refreshToken = res.data.refreshToken
					const accessToken = res.data.accessToken
					uni.request({
						url:'http://127.0.0.1:3007/userPersonal/visitUserIndex',
						method:'GET',
						data:{
							id:id,
							type:type
						},
						header: {
						  'content-type': 'application/json',
						  'Authorization': 'Bearer '+accessToken
						},
						success: (res) => {
							console.log(res)
							if(res.data.message=='身份验证失败'){
								refreshTokenGlobal(refreshToken).then(()=>{
									if(hasRefresh==false){
										hasRefresh=true
										getUserInfoNTieArray(id,type,true)
									}else{
										console.log('refreshToken fail')
									}
									
								}).catch((err)=>{
									console.log(err)
								})
							}else{
								avatarUrl.value = res.data.avatarUrl
								nickname.value = res.data.nickname
								major.value = res.data.major
								gender.value = res.data.gender
								shortIntroduce.value = res.data.shortIntroduce
								tieArray.value = res.data.tieArray
							}
							
						},
						fail: (err) => {
							console.log(err)
						}
					})
				}
			})
		}
	}
	function navigateToUserDetail(type,id){
		console.log(type,id)
		uni.navigateTo({
			url:`../userIndex/userIndex?type=${type}&id=${id}`
		})
	}
	onPageScroll((e)=>{
		scrollTop.value = e.scrollTop;
	})
	function toPaise (acceptId,index,hasRefresh= false){
		if(!global.isLogin.value){
			showLoginTip('../../pages/login/login')
		}else{
			const send_time = Date.now()
			const type = 'tiezi'
			uni.getStorage({
				key:'tokens',
				success: (res) => {
					const refreshToken = res.data.refreshToken
					const accessToken = res.data.accessToken
					uni.request({
						url:'http://127.0.0.1:3007/userPersonal/toPaise',
						method:'POST',
						data:{
							acceptId,
							send_time,
							type
						},
						header: {
						  'content-type': 'application/json',
						  'Authorization': 'Bearer '+accessToken
						},
						success: (res) => {
							console.log(res)
							if(res.data.message=='身份验证失败'){
								refreshTokenGlobal(refreshToken).then(()=>{
									if(hasRefresh==false){
										hasRefresh=true
										toPaise(acceptId,index,true)
									}else{
										console.log('refreshToken fail')
									}
									
								}).catch((err)=>{
									console.log(err)
								})
							}else{
								tieArray.value[index].hasPaise = 1
								tieArray.value[index].like_count++
							}
							
						},
						fail: (err) => {
							console.log(err)
						}
					})
				}
			})
		}
		
		
	}
	function toStopPaise(acceptId,index,hasRefresh= false){
		if(!global.isLogin.value){
			showLoginTip('../../pages/login/login')
		}else{
			const send_time = Date.now()
			const type = 'tiezi'
			uni.getStorage({
				key:'tokens',
				success: (res) => {
					const refreshToken = res.data.refreshToken
					const accessToken = res.data.accessToken
					uni.request({
						url:'http://127.0.0.1:3007/userPersonal/toStopPaise',
						method:'POST',
						data:{
							acceptId
						},
						header: {
						  'content-type': 'application/json',
						  'Authorization': 'Bearer '+accessToken
						},
						success: (res) => {
							console.log(res)
							if(res.data.message=='身份验证失败'){
								refreshTokenGlobal(refreshToken).then(()=>{
									if(hasRefresh==false){
										hasRefresh=true
										toStopPaise(acceptId,index,true)
									}else{
										console.log('refreshToken fail')
									}
									
								}).catch((err)=>{
									console.log(err)
								})
							}else{
								tieArray.value[index].hasPaise = 0
								tieArray.value[index].like_count--
							}
							
						},
						fail: (err) => {
							console.log(err)
						}
					})
				}
			})
		}
	}
	function toStore(tieId,index,hasRefresh= false){
		if(!global.isLogin.value){
			showLoginTip('../../pages/login/login')
		}else{
			const store_time = Date.now()
			uni.getStorage({
				key:'tokens',
				success: (res) => {
					const refreshToken = res.data.refreshToken
					const accessToken = res.data.accessToken
					uni.request({
						url:'http://127.0.0.1:3007/userPersonal/toStore',
						method:'POST',
						data:{
							tieId,
							store_time
						},
						header: {
						  'content-type': 'application/json',
						  'Authorization': 'Bearer '+accessToken
						},
						success: (res) => {
							console.log(res)
							if(res.data.message=='身份验证失败'){
								refreshTokenGlobal(refreshToken).then(()=>{
									if(hasRefresh==false){
										hasRefresh=true
										toStore(tieId,index,hasRefresh)
									}else{
										console.log('refreshToken fail')
									}
									
								}).catch((err)=>{
									console.log(err)
								})
							}else{
								tieArray.value[index].hasStore=1
								tieArray.value[index].store_count++
							}
							
						},
						fail: (err) => {
							console.log(err)
						}
					})
				}
			})
		}
	}
	function toStopStore(tieId,index){
		if(!global.isLogin.value){
			showLoginTip('../../pages/login/login')
		}else{
			const store_time = Date.now()
			uni.getStorage({
				key:'tokens',
				success: (res) => {
					const refreshToken = res.data.refreshToken
					const accessToken = res.data.accessToken
					uni.request({
						url:'http://127.0.0.1:3007/userPersonal/toStopStore',
						method:'POST',
						data:{
							tieId
						},
						header: {
						  'content-type': 'application/json',
						  'Authorization': 'Bearer '+accessToken
						},
						success: (res) => {
							console.log(res)
							if(res.data.message=='身份验证失败'){
								refreshTokenGlobal(refreshToken).then(()=>{
									if(hasRefresh==false){
										hasRefresh=true
										toStore(tieId,index,hasRefresh)
									}else{
										console.log('refreshToken fail')
									}
									
								}).catch((err)=>{
									console.log(err)
								})
							}else{
								tieArray.value[index].hasStore=0
								tieArray.value[index].store_count--
							}
						},
						fail: (err) => {
							console.log(err)
						}
					})
				}
			})
		}
	}
	function navigateToDetail(tieId){
		uni.navigateTo({
			url:`../tieDetail/tieDetail?tieId=${tieId}`
		})
	}
	function toFocus (id,type,hasRefresh=false){
		if(!global.isLogin.value){
			showLoginTip('../../pages/login/login')
		}else{
			const focus_time = Date.now()
			uni.getStorage({
				key:'tokens',
				success: (res) => {
					const refreshToken = res.data.refreshToken
					const accessToken = res.data.accessToken
					uni.request({
						url:'http://127.0.0.1:3007/userPersonal/toFocus',
						method:'POST',
						data:{
							focus_time,
							id,
							type
						},
						header: {
						  'content-type': 'application/json',
						  'Authorization': 'Bearer '+accessToken
						},
						success: (res) => {
							console.log(res)
							if(res.data.message=='身份验证失败'){
								refreshTokenGlobal(refreshToken).then(()=>{
									if(hasRefresh==false){
										hasRefresh=true
										toFocus(id,type,hasRefresh)
									}else{
										console.log('refreshToken fail')
									}
									
								}).catch((err)=>{
									console.log(err)
								})
							}else{
								hasFocus.value = true
							}
						},
						fail: (err) => {
							console.log(err)
						}
					})
				}
			})
		}
	}
	function toCancelFocus (id,type,hasRefresh=false){
		if(!global.isLogin.value){
				showLoginTip('../../pages/login/login')
			}else{
				uni.getStorage({
					key:'tokens',
					success: (res) => {
						const refreshToken = res.data.refreshToken
						const accessToken = res.data.accessToken
						uni.request({
							url:'http://127.0.0.1:3007/userPersonal/toCancelFocus',
							method:'POST',
							data:{
								id,
								type,
							},
							header: {
							  'content-type': 'application/json',
							  'Authorization': 'Bearer '+accessToken
							},
							success: (res) => {
								console.log(res)
								if(res.data.message=='身份验证失败'){
									refreshTokenGlobal(refreshToken).then(()=>{
										if(hasRefresh==false){
											hasRefresh=true
											toCancelFocus(id,type,hasRefresh)
										}else{
											console.log('refreshToken fail')
										}
										
									}).catch((err)=>{
										console.log(err)
									})
								}else{
									hasFocus.value = false
								}
							},
							fail: (err) => {
								console.log(err)
							}
						})
					}
				})
			}
	}
	onLoad((e)=>{
		console.log(e)
		id.value = e.id
		type.value = e.type
		getUserInfoNTieArray(e.id,e.type)
		isYourself.value =Boolean(e.isYourself)
	})
	
</script>

<style>

	.nav-bar{
		/* background-color: #092438; */
		background-color: #447db9; 
		position: fixed;
		width: 100%;
		top: 0;
		z-index: 1500;
	}
	.navBarTitle{
		background-color: transparent;
		width: 130rpx;
		position: fixed;
		color: #ffffff;
		left: 300rpx;
	}
	.leftArrow{
		position: fixed;
		left: 20rpx;
		z-index: 2000;
	}
	.leftArrow image{
		width: 50rpx;
		height: 50rpx;
	}
	.avatarBox{
		margin-left: 30rpx;
	}
	.userAvatarBox image {
		width: 120rpx;
		height: 120rpx;
		border-radius: 100%;
		position: relative;
		top: -40rpx;
		border: 10rpx solid #fffffd;
		margin-left: 30rpx;
	}
	.topBox{
		width: 100%;
		height: 300rpx;
		background-color: #447db9;
	}
	.fixedTopBox{
		display: fixed;
		top: 480rpx;
	}
	.topBox image{
		width: 100%;
		height: 350rpx;
	}
	.infoBox{
		width: 100%;
		z-index: 999;
		border-radius: 20rpx 20rpx 0 0;
		background-color: #fffffd;	
	}
	.name_fen_guan_fred {
		
	}
	.fen_guan_fred{
		display: flex;
	}
	/* .name {
		font-size: 32rpx;
		color: #333333;
		margin: 20rpx 0 0 0rpx;
		font-weight: 600;
	} */
	.countUp{
		display: flex;
		margin: 10rpx 20rpx 10rpx;
		justify-content: center;
	}
	.count{
		color: #333333;
		margin-right: 10rpx;
		font-weight: 600;
	}
	.countTitle{
		color: #979797;
		font-size: 29rpx;
	}
	.avaNamBox{
		display: flex;
	}
	.jianjie{
		width: 90%;
		margin:10rpx 0 0rpx 5%;
		padding-bottom: 20rpx;
		overflow-wrap: break-word;
		color: #949494;
		font-size: 25rpx;
	}
	.editButton {
		display: flex;
		align-items: center;
		justify-content: center;
		width: 40%;
		margin-left:30% ;
		border: #e0e0e0 solid 2rpx;
		border-radius: 20rpx;
	}
	.editIcon image{
		width: 27rpx;
		height: 27rpx;
		padding-right: 10rpx;
	}
	.editFont{
		font-size: 22rpx;
		color: #999999;
	}
	.tabbar{
		width: 60%;
		margin:20rpx 20% 0 20%;
		color: #ececec;
		font-size: 32rpx;
		display: flex;
		justify-content: space-around;
		align-items: center;
	}
	.unselectedItem {
		padding: 20rpx;
		color: #989898;
	}
	.selectedItem {
		color: #363636;
		padding: 20rpx;
		font-weight: 600;
	}
	.selectLine {
		height: 7rpx;
		width: 40rpx;
		border-radius: 10rpx;
		background-color: #1b72b1;
		position: relative;
		top: -10rpx;
		
		transition: 0.2s;
	}
	.zanDetail{
		height: 900rpx;
	}
	.shoucang{
		height:900rpx;
	}
	.tieDetail{
		height: 900rpx;
	}
	.normal {
		border-top: #9e9e9e solid 3rpx;

	}
	.tieItem{
		background-color: #ffffff;
		width: 100%;
		border-bottom: solid 1rpx #dddddd;
		display: flex;
	}
	.avatarBox{}
	.avatarBox image{
		width: 90rpx;
		height: 90rpx;
		margin: 20rpx;
		border-radius: 100%;
	}
	.name_time{
		margin-top: 30rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding-right: 20rpx;
	}
	.name{
		font-size: 31rpx;
		color: #427eab;
		margin-right: 20rpx;
		width: max-content;
		font-weight: 600;
	}
	.time{
		font-size: 23rpx;
		color: #6e7082;
	}
	.content{
		margin-top: 30rpx;
		font-size: 30rpx;
		width: 70%;
		overflow: hidden;
		text-overflow: ellipsis;
		text-wrap: wrap;
		color: #292a2d;
		font-size: 30rpx;
		-webkit-box-orient: vertical;
		/* -webkit-line-clamp: 5; */
		min-height: 40rpx;
		max-height: 160rpx;
	}
	.table{
		margin-top: 10rpx;
		padding: 4rpx;
		width: max-content;
		margin-top: 10rpx;
		color: #0d469a;
		background-color: #dae7f8;
		border-radius: 10rpx;
		padding-right: 10rpx;
		padding: 5rpx;
		font-size: 25rpx;
	}
	.buttons{
		margin-left: 280rpx;
		width: 300rpx;
		display: flex;
		justify-content: space-around;
	}
	.paiseBox{
		display: flex;
	}
	.paiseImgBox image{
		width: 30rpx;
		height: 30rpx;
		padding-right: 10rpx;
	}
	.paiseCount{
		font-size: 28rpx;
		color: #646464;
	}
	.paiseFont{
		font-size: 28rpx;
		color: #000000;
	}
	.commentsBox{
		display: flex;
	}
	.commentsImgBox image{
		width: 35rpx;
		height: 35rpx;
		padding-right: 10rpx;
	}
	.commentsCount{
		font-size: 28rpx;
		color: #000000;
	}
	.commentsFont{
		font-size: 28rpx;
		color: #000000;
	}
	.images{
		display: grid;
		grid-template-columns: repeat(2,1fr);
		grid-template-rows: 1;
		height: 200rpx;
		width: 540rpx;
		gap: -20rpx;
		overflow: hidden;
		margin-top: 10rpx;
	}
	.imageItem{
		/* margin-right: 30rpx; */
		height: 200rpx;
		width: 250rpx;
	}
	.imageItem image{
		height: 200rpx;
		width: 250rpx;
		border-radius: 20rpx;
	}
	.focusButton_name {
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: max-content;
		margin: 20rpx 0rpx 0rpx 20rpx;
	}
	.focusButton {
		font-size: 25rpx;
		color: #ffffff;
		background-color: #54a2da;
		border-radius: 10rpx;
		padding: 8rpx 22rpx 8rpx 22rpx;
		position: absolute;
		right: 30rpx;
		top: 319rpx;
	}
	.selectedButton {
		font-size: 25rpx;
		color: #ffffff;
		background-color: #7b7b84;
		border-radius: 10rpx;
		padding: 8rpx 22rpx 8rpx 22rpx;
		position: absolute;
		right: 30rpx;
		top: 319rpx;
	}
</style>
