<template>
	<view>
		<uni-nav-bar title="设置" statusBar='true' backgroundColor='#447db9' color='#eaebeb' fixed='true' left-icon="back" @clickLeft="navigateToBack" leftWidth='80'></uni-nav-bar>
		<view class="changeAcountBox">
			<view v-for="(accountItem,index) in accounts" class="acountItem">
				<view class="acountInfoBox">
					<view class="acountAvatar">
						<image :src="accountItem.avatar"></image>
					</view>
					<view class="acountName">{{accountItem.nickName}}</view>
				</view>
				<view class="gouBox">
					<image v-if="accountItem.isLogin" src="../../static/勾子.png"></image>
				</view>
			</view>
			<view class="addAccount">
				<view class="addIcon">
					<image src="../../static/添加 (3).png"></image>
				</view>
				<view class="addFont">添加账号</view>
			</view>
			
		</view>
		
		<view class="outOfAcount">
			<view class="outOfAcountFont" @click="tapLogOut">退出登录</view>
		</view>
	</view>
	
</template>

<script setup>
	import {getCurrentInstance , ref,inject} from 'vue'
	const {
			appContext: {
				config: {
					globalProperties: global
				}
			}
			} = getCurrentInstance();
	const globalUserState = inject('globalUserState')
	const accounts = [
		{
			nickName:'眼睛小的吃瓜群众',
			openid:'123123123123123',
			avatar:'../../static/backgroundIMG.png',
			isLogin:true
		},
		{
			nickName:'眼睛小的吃瓜群众',
			openid:'123123123123123',
			avatar:'../../static/backgroundIMG.png'
		},
		{
			nickName:'眼睛小的吃瓜群众',
			openid:'123123123123123',
			avatar:'../../static/backgroundIMG.png'
		}
	]
	function navigateToBack(){
		uni.navigateBack()
	}
	function tapLogOut(){
		uni.showModal({
		    title: '退出登录',
		    content: '您确定要退出登录吗？',
		    success: function (res) {
		      if (res.confirm) {
		        // 如果用户点击了确认按钮
		        console.log('用户点击确定按钮');
		        uni.clearStorage()
				// global.isLogin = ref(false)
				// global.userInfo = ref({})
				globalUserState.isLogin=false
				globalUserState.userInfo = {}
				console.log(global)
		        uni.navigateTo({
		          url: '/pages/login/login' // 假设这是登录页面的路径
		        });
		      } else if (res.cancel) {
		        // 如果用户点击了取消按钮
		        console.log('用户点击取消按钮');
		        // 这里可以不做任何操作，或者提示用户取消退出
		      }
		    }
		  });
	}
</script>

<style>
	.changeAcountBox{
		width: 94%;
		margin-left: 3%;
		background-color: #ffffff;
		border-radius: 20rpx;
		margin-top: 20rpx;
		border: #f2f2f2 1rpx solid;
	}
	.acountItem{
		display: flex;
		align-items:center;
		justify-content: space-between;
		padding: 25rpx;
	}
	.acountInfoBox{
		display: flex;
		align-items: center;
	}
	.acountAvatar image{
		border-radius: 100%;
		width: 85rpx;
		height: 85rpx;
	}
	.acountName{
		font-size: 26rpx;
		color: #515151;
		letter-spacing: 3rpx;
		margin-left: 20rpx;
	}
	.gouBox image{
		width: 30rpx;                                  
		height: 30rpx;
	}
	.addAccount {
		padding: 25rpx;
		padding-left: 30rpx;
		display: flex;
		align-items: center;
	}
	.addIcon image{
		padding-top: 10rpx;
		width: 45rpx;
		height: 45rpx;
	}
	.addFont{
		font-size: 28rpx;
		margin-left: 30rpx;
	}
	.outOfAcount {
		display: flex;
		justify-content: center;
		align-items: center;
		background-color: #ffffff;
		margin-top: 20rpx;
		padding: 20rpx;
		width: 89%;
		margin-left: 3%;
		border-radius: 20rpx;
		border: #f2f2f2 1rpx solid;
	}
	.outOfAcountFont {
		min-width: 50rpx;
		max-width: 200rpx;
		
	}
</style>
