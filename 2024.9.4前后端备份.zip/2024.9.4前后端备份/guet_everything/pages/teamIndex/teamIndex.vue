<template>
	<view>
		<view class="nav-bar" :style="{height:navBarHeight,opacity:navBarOpacity}"></view>
		<view class="leftArrow" :style="{top:LeftArrowTop}" @click="toSearch">
			<image src="../../static/查询.png"></image>
		</view>
		
		<view class="buttons" :style="{marginTop:navBarHeight}">
			<view class="button">
				<view class="imageBox">
					<image src="../../static/好友.png" class="buttonImage"></image>
				</view>
				<view class="buttonFont">我加入的局</view>
			</view>
			<view class="button">
				<view class="imageBox">
					<image src="../../static/旗子.png" class="buttonImage"></image>
				</view>
				<view class="buttonFont">发起攒局</view>
			</view>
		</view>
		
		<view class="tablesBox">
			<view class="table" style="box-shadow:  5rpx 5rpx 0 0  #959596,inset 13rpx 0 0 0 #c1384b;">
				<view class="tableIcon">
					<image src="../../static/勾.png"></image>
				</view>
				<view class="tableName" >有空位</view>
			</view>
			<view class="table" style="box-shadow:  5rpx 5rpx 0 0  #959596,inset 13rpx 0 0 0 #1a9de3;">
				<view class="tableTitle">自习</view>
				<view class="tableCount">（2）</view>
			</view>
			<view class="table" style="box-shadow:  5rpx 5rpx 0 0  #959596,inset 13rpx 0 0 0 #2fc138;">
				<view class="tableTitle">电影</view>
				<view class="tableCount">（3）</view>
			</view>
			<view class="table" style="box-shadow:  5rpx 5rpx 0 0  #959596,inset 13rpx 0 0 0 #c1384b;">
				<view class="tableTitle">聚餐</view>
				<view class="tableCount">（4）</view>
			</view>
			<view class="table" style="box-shadow:  5rpx 5rpx 0 0  #959596,inset 13rpx 0 0 0 #1a9de3;">
				<view class="tableTitle">拼车</view>
				<view class="tableCount">（5）</view>
			</view>
			<view class="table" style="box-shadow:  5rpx 5rpx 0 0  #959596,inset 13rpx 0 0 0 #2fc138;">
				<view class="tableTitle">拼单</view>
				<view class="tableCount">（6）</view>
			</view>
			<view class="table" style="box-shadow:  5rpx 5rpx 0 0  #959596,inset 13rpx 0 0 0  #c1384b;">
				<view class="tableTitle">运动</view>
				<view class="tableCount">（7）</view>
			</view>
			<view class="table" style="box-shadow:  5rpx 5rpx 0 0  #959596,inset 13rpx 0 0 0 #1a9de3;">
				<view class="tableTitle">游戏</view>
				<view class="tableCount">（8）</view>
			</view>
			<view class="table" style="box-shadow:  5rpx 5rpx 0 0  #959596,inset 13rpx 0 0 0 #2fc138;">
				<view class="tableTitle">旅行</view>
				<view class="tableCount">（9）</view>
			</view>
			<view class="table" style="box-shadow:  5rpx 5rpx 0 0  #959596,inset 13rpx 0 0 0 #c1384b;">
				<view class="tableTitle">其他</view>
				<view class="tableCount">（10）</view>
			</view>
		</view>
		
		<view class="cards">
			<view class="cardItem">
				<view class="cardHead" style="background-color: #c1384b;">精选</view>
				<view class="detail">
					<view class="content">意上两小帅小美lalallalalallalalallalalalalalalallalalllllllllllllllllllll</view>
					<view class="leader_time">
						<view class="leader">
							<view >局长：胡图图</view>
							<view class="sexBox">
							<image src="../../static/tabbar3_s (2).png"></image>
							</view>
						</view>
						<view class="time">4天前</view>
					</view>
					<view class="progress"></view>
				</view>
			</view>
			<view class="cardItem">
				<view class="cardHead" style="background-color: #c1384b;">精选</view>
				<view class="detail">
					<view class="content">意上两小帅小美lalallalalallalalallalalalalalalallalalllllllllllllllllllll</view>
					<view class="leader_time">
						<view class="leader">
							<view >局长：胡图图</view>
							<view class="sexBox">
							<image src="../../static/tabbar3_s (2).png"></image>
							</view>
						</view>
						<view class="time">4天前</view>
					</view>
					<view class="progress"></view>
				</view>
			</view>
			<view class="cardItem">
				<view class="cardHead" style="background-color: #c1384b;">精选</view>
				<view class="detail">
					<view class="content">意上两小帅小美lalallalalallalalallalalalalalalallalalllllllllllllllllllll</view>
					<view class="leader_time">
						<view class="leader">
							<view >局长：胡图图</view>
							<view class="sexBox">
							<image src="../../static/tabbar3_s (2).png"></image>
							</view>
						</view>
						<view class="time">4天前</view>
					</view>
					<view class="progress"></view>
				</view>
			</view>
			<view class="cardItem">
				<view class="cardHead" style="background-color: #c1384b;">精选</view>
				<view class="detail">
					<view class="content">意上两小帅小美lalallalalallalalallalalalalalalallalalllllllllllllllllllll</view>
					<view class="leader_time">
						<view class="leader">
							<view >局长：胡图图</view>
							<view class="sexBox">
							<image src="../../static/tabbar3_s (2).png"></image>
							</view>
						</view>
						<view class="time">4天前</view>
					</view>
					<view class="progress"></view>
				</view>
			</view>
		</view>
	</view>
</template>

<script setup>
	function toSearch(){
		
	}
	import {onLoad,onReady,onShow,onUnload,onPageScroll} from "@dcloudio/uni-app"
	import { getCurrentInstance,ref,computed } from 'vue';
	const {
		appContext:{
			config:{
				globalProperties:global
			}
		}
	} = getCurrentInstance();
	console.log(global,global.Custom.bottom,global.Custom.height*2);
	const navBarHeight = global.Custom.bottom*2+15+"rpx";
	const LeftArrowTop = global.Custom.bottom*2-60+"rpx";
	console.log(navBarHeight,LeftArrowTop)
	var scrollTop = ref(0);
	var navBarOpacity = computed(()=>{
		if(scrollTop.value >100){
			return 1;
		}else{
			return scrollTop.value/100;
		}
	})
	const scrollHeight = computed(()=>{
		return global.safeArea.bottom*2+"rpx";
	})
	onPageScroll((e)=>{
		console.log(e);
		scrollTop.value = e.scrollTop;
		console.log(scrollTop ,navBarOpacity._value);
	})
	
</script>

<style>
 page{
	 background-color: #fbd975;
 }
 .nav-bar{
 	/* background-color: #092438; */
 	background-color: #fbd975; 
 	position: fixed;
 	width: 100%;
 	top: 0;
 	z-index: 1500;
 }
 .leftArrow{
 	position: fixed;
 	left: 20rpx;
 	z-index: 2000;
 }
 .leftArrow image{
 	width: 50rpx;
 	height: 50rpx;
 }
 .buttons{
	 width: 90%;
	 margin-left: 5%;
	display: flex;
	justify-content: space-around;
 }
 .button:first-of-type{
	 background-color:  #62adfc;
	 box-shadow: inset 6rpx 6rpx 0 0 #a1cefd ,inset -6rpx -6rpx #167bde;
 }
 .button:last-of-type{
	 background-color: #fd6a63;
	 box-shadow: inset 6rpx 6rpx 0 0 #f9aba3 ,inset -6rpx -6rpx #d9241b;
 }
 .button{
	 height: 90rpx;
	 width: 45%;
	 display: flex;
	 border: #565656 solid 6rpx;
	 justify-content: center;
	 align-items: center;
	 border-radius: 50rpx;
	 
 }
 .imageBox image{
	 width: 32rpx;
	 height: 32rpx;
 }
 .buttonFont{
	 font-size: 32rpx;
	 color: aliceblue;
	 margin-left: 13rpx;
 }
 .tablesBox{
	 width: 96%;
	 margin-left: 2%;
	 display: flex;
	 margin-top: 35rpx;
	 justify-content: space-around;
	 flex-wrap: wrap;
 }
 .table{
	 width: 15.5%;
	 display: flex;
	 justify-content: center;
	 align-items: center;
	 background-color: aliceblue;
	 border-radius: 20rpx;
	 padding: 10rpx;
	 margin-bottom: 15rpx;
	 height: 44rpx;
	 border: solid black 5rpx;
 }
 .tableName{
	 font-weight: 600;
	 color: #2d2d2d;
	 font-size: 24rpx;
 }
 .tableCount{
	 color: #2d2d2d;
	 font-size: 21rpx;
 }
 .tableTitle{
	 font-weight: 600;
	 color: #2d2d2d;
	 font-size: 24rpx;
 }
 .tableIcon{
	 width: 24rpx;
	 height: 24rpx;
 }
 .tableIcon image{
	 width: 24rpx;
	 height: 24rpx;
 }
 .cards{
	 margin-top: 20rpx;
 }
 .cardItem{
	 display: flex;
	 height: 240rpx;
	 width: 94%;
	 margin-left: 3%;
	 border: #2d0101 solid 4rpx;
	 border-radius: 20rpx;
	 background-color: #efefef;
	 box-shadow: #565656 10rpx 10rpx 0 0 ;
	 margin-bottom: 25rpx;
 }
 .cardHead{
	 font-size: 50rpx;
	 padding: 47rpx 20rpx;
	 width: 70rpx;
	 text-wrap: wrap;
	 font-family: 'STHupo';
	 border-radius: 15rpx  0 0 15rpx ;
	 line-height: 70rpx;
	 color: #d6d6d6;
 }
 .detail{
	 width: 100%  ;
	 padding: 20rpx;
 }
 .content{
	 width:568rpx;
	 font-size: 31rpx;
	 font-weight: 600;
	 letter-spacing: 2rpx;
	 height: 130rpx;
	 overflow: hidden;
	 text-overflow: ellipsis;
	 -webkit-line-clamp: 2;
	 color: #252120;
 }
 .leader_time{
	 width:100%;
	 display: flex;
	 justify-content: space-between;
	 align-items: center;
 }
 .leader{
	 display:flex;
	 font-size: 28rpx;
	 color: #0a8bb9;
 }
 .time{
	 font-size: 27rpx;
	 color: #7e7e7e;
 }
 .sexBox image{
	 width: 26rpx;
	 height: 26rpx;
	 margin-left: 10rpx;
 }
 .progress {
	 
 }
</style>
