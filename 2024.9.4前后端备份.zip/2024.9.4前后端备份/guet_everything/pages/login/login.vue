<template>
	<view>
		<!-- <uni-nav-bar title="登录" statusBar='true' backgroundColor='#447db9' color='#eaebeb' ></uni-nav-bar> -->
		<view class="everything">Everything</view>
		<view class="guet">—— GUET</view>
		<view class="title">微信一键授权登录</view>
		<!-- <button  @click="getUserProfile"> 获取头像昵称 </button> -->
		<button class="loginButton"  :disabled="buttonDisabled" @click="getUserProfile">立即登录</button>
		<!-- <button class="loginButton" open-type="chooseAvatar" :disabled="buttonDisabled" @chooseavatar="onChooseAvatar">立即登录</button> -->
		<view class="phoneBox">
			<view class="phoneFont">使用手机号进行登录</view>
			<view class="rightArrow">
				<image src="../../static/右箭头 (3).png"></image>
			</view>
		</view>
		<view class="bottom" @click="backToIndex">暂不登录</view>
		<!-- <input type="nickname"  placeholder="获取昵称"  @focus="onNicknameInput"/> -->
	</view>
</template>

<script setup>
	import { getCurrentInstance, ref,inject} from 'vue';
	const {
			appContext: {
				config: {
					globalProperties: global
			}
				}
		} = getCurrentInstance();
	const globalUserState = inject('globalUserState')
	var userInfo =null
	var code = ''
	const normalUserInfo ={
		nickName:"微信用户",
		gender:0,
		avatarUrl:"https://thirdwx.qlogo.cn/mmopen/vi_32/POgEwh4mIHO4nibH0KlMECNjjGxQUq24ZEaGT4poC6icRiccVGKSyXwibcPq4BWmiaIGuG1icwxaQX6grC9VemZoJ8rg/132"
	}
	var buttonDisabled = ref(false)
	function toLogin(userInfo){
		uni.login({
			success: (res) => {
				console.log(res)
				code = res.code
				console.log('code',code)
				uni.request({
					url:'http://127.0.0.1:3007/user/trylogin',
					data:{
						code:code,
						userInfo:userInfo
					},
					method:'POST',
					header: {
						'content-type': 'application/json'
					},
					success:(res)=>{
						console.log(res)
						if(res.statusCode==200){
							if(res.data.status==1){
								uni.hideLoading();
								loseToLogin()
								return
							}
							if(userInfo==null){
								userInfo ={...normalUserInfo,openid:res.data.openid}
							}else{
								userInfo ={...userInfo,openid:res.data.openid}
							}
							if(res.data.modifed_time){
								userInfo ={...userInfo,modifed_time:res.data.modifed_time}
							}else if(res.data.create_time){
								userInfo ={...userInfo,create_time:res.data.create_time}
							}
							console.log(userInfo)
							global.userInfo = ref(userInfo)
							global.isLogin =ref(true)
							// console.log(global)
							const tokens = {
								accessToken:res.data.accessToken,
								refreshToken:res.data.refreshToken
							}
							uni.setStorage({
								key:'tokens',
								data:tokens,
								success: (e) => {
									console.log(e)
									backToIndex();
								},
								fail:(err)=> {
									console.log(err)
									loseToLogin()
								},complete:()=>{
									uni.hideLoading();
									buttonDisabled.value = false
								}
							})
						}
					},
					fail: (err) => {
						console.log(err)
						uni.hideLoading();
						buttonDisabled.value = false
						loseToLogin()
					}
				})
			},
			fail: (err) => {
				console.log(err)
				uni.hideLoading();
				buttonDisabled.value = false
				loseToLogin()
			}
		})
		
	}
	function backToIndex (){
		uni.switchTab({
			url:'../index/index'
		})
	}
	function loseToLogin (){
		uni.showToast({
			title: '登录失败，请重试',
			  icon: 'none'
		})
	}
	function getUserProfile(e) {
	    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认
	    // 开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
	    wx.getUserProfile({
	      desc: '用于完善会员资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
	      success: (res) => {
			  uni.showLoading({
			    title: '加载中'
			  });
	        console.log(res)
			const  {nickName,gender,avatarUrl} = res.userInfo
			userInfo = {nickName,gender,avatarUrl}
			console.log('userInfo',userInfo)
			toLogin(userInfo)
	      },
		  fail: (err) => {
		  	console.log('用户拒绝信息授权')
			uni.showLoading({
			  title: '加载中'
			});
			toLogin(userInfo)
		  }
	    })
	  }
	// function  onChooseAvatar(e){
	// 	console.log(e)
	// }
	// function onNicknameInput(e){ 
	// 					console.log(e);
	// 					this.nickName= e.detail.value
	// 				}
</script>
<style>
	page{
		background-color: #2e7bcc;
	}
	.everything{font-size: 80rpx;
		color: #fafafa;
		margin:400rpx 0 0 175rpx;
		font-weight: 600;
		font-family: 'Times New Roman', Times, serif;
		}
	.guet{
		font-size: 37rpx;
		color: #fafafa;
		margin:30rpx 0 0 500rpx;
		font-weight: 600;
		font-family: 'Times New Roman', Times, serif;
	}
	.title{
		font-size: 35rpx;
		color: #ededef;
		margin:300rpx 0 0 225rpx;
		/* font-weight: 600; */
	}
	.loginButton{
		width: 60%;
		margin: 100rpx 0 50rpx 20%;
		color: aliceblue;
		background-color: #3bb9ea;
		border-radius: 50rpx;
	}
	.phoneBox{
		display: flex;
		align-items: center;
		margin-left: 35%;
	}
	
	.phoneFont {
		color: #dedede;
		font-size: 23rpx;
	}
	.rightArrow{
		
	}
	.rightArrow image{
		width: 22rpx;
		height: 22rpx;
		margin-left: 8rpx;
	}
	.bottom {
		color: #cacaca;
		font-size: 23rpx;
		width: 100rpx;
		margin-top: 50rpx;
		border-bottom: #cacaca solid 2rpx;
		margin-left: 43%;
	}
</style>
