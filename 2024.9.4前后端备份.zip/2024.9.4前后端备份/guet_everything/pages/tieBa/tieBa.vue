<template>
	<view>
		<uni-nav-bar title="贴吧" statusBar='true' backgroundColor='#447db9' color='#eaebeb' fixed='true' left-icon="search" @clickLeft="navigateToSearch" leftWidth=80></uni-nav-bar>
		<movable-area>
			<view class="tieItem" v-for="(tieItem,index) in tieArray" :key="index">
				<view class="avatarBox">
					<image @click="navigateToUserDetail('tiezi',tieItem.tieId)" :src="tieItem.avatarUrl" ></image>
				</view>
				<view class="infoBox" @click="navigateToDetail(tieItem.tieId)">
					<view class="name_time">
						<view class="name" @click.stop="navigateToUserInfo">{{tieItem.nickname}}</view>
						<view class="time">{{tieItem.uploadTime}}</view>
					</view>
					<view class="content">{{tieItem.content}}</view>
					<view class="images" v-if="tieItem.images!==null">
						<view class="imageItem" v-for="(imageItem,imageIndex) in tieItem.images"     key="imageIndex">
							<image  @click.stop="previewImage(tieItem.images,imageIndex)" mode="aspectFill" :src="imageItem"></image>
						</view>
					</view>	
					<view class="table">{{tieItem.tag}}</view>
					<view class="buttons">
						<view class="paiseBox">
							<view class="paiseImgBox">
								<image @click.stop="toStopPaise(tieItem.tieId,index)" v-if="tieItem.hasPaise==1" src="../../static/点赞 (3).png"></image>
								<image @click.stop="toPaise(tieItem.tieId,index)" v-if="!tieItem.hasPaise==1" src="../../static/点赞 (2).png"></image>
							</view>
							<view class="paiseCount" >{{tieItem.like_count}}</view>
						</view>
						<view class="paiseBox">
							<view class="paiseImgBox">
								<image @click.stop ="toStopStore(tieItem.tieId,index)" v-if="tieItem.hasStore==1" src="../../static/收藏_fill.png"></image>
								<image @click.stop ="toStore(tieItem.tieId,index)" v-if="!tieItem.hasStore==1" src="../../static/收藏.png"></image>
							</view>
							<view class="paiseCount" >{{tieItem.store_count}}</view>
						</view>
						<view class="commentsBox">
							<view class="commentsImgBox">
								<image @click.stop="toComment" src="../../static/评论 (1).png" ></image>
							</view>
							<view class="commentsCount" >{{tieItem.comment_count}}</view>
						</view>
					</view>
				</view>
			</view>
			<movable-view class="mov_view" direction="all" :x="view_X" :y="view_Y" damping="20" friction="3" @change="viewMoveing" @click="navigateToPublish" >
					<view class="mov_img">
						<image src="../../static/ic_add.png"></image>
					</view>
			</movable-view>
		</movable-area>	
	</view>
</template>

<script setup>
	import {onLoad,onReady,onShow,onUnload,onPageScroll} from "@dcloudio/uni-app"
	import { getCurrentInstance,ref,computed,inject } from 'vue';
	const {
		appContext:{
			config:{
				globalProperties:global
			}
		}
	} = getCurrentInstance();
	console.log(global,global.Custom.bottom,global.Custom.height*2);
	const navBarHeight = global.Custom.bottom*2+15+"rpx";
	const refreshTokenGlobal = inject('refreshTokenGlobal');
	var view_X = ref(320);
	var view_Y = ref(680);
	var cursorId = ref(null)
	var cursorSql = computed(()=>{
		return cursorId?`cursorId=${cursorId.value}`:''
	})
	var showTitle = false;
	const tieArray = ref([])
	onLoad(()=>{
		uni.getStorage({
			key:'tokens',
			success: (res) => {
				console.log(res)
				const refreshToken = res.data.refreshToken||null
				const accessToken = res.data.accessToken||null
				var Bearer = ''
				if(refreshToken!==null&&accessToken!==null){
					Bearer = 'Bearer '+accessToken
				}
				uni.request({
					url:`http://127.0.0.1:3007/user/showTieZi?${cursorSql}`,
					method:'GET',
					header:{
						'Authorization':`${Bearer}`
					},
					success: (res) => {
						console.log(res)
						tieArray.value = res.data
					},
					fail: (err) => {
						console.log(err)
					}
				})
			}
		})
		
	})
	function viewMoveing (e){
	}
	function toPaise (acceptId,index,hasRefresh= false){
		if(!global.isLogin.value){
			uni.showModal({
				title:'登录提示',
				content:'用户尚未登录，请先登录再进行操作，是非前往登录？',
				success:(res)=>{
					if(res.confirm){
						uni.navigateTo({
							url:'../login/login'
						})
					}else{
						if(res.cancel){
							return
						}
					}
					
				},
				fail: (err) => {
					return
				}
			})
		}else{
			const send_time = Date.now()
			const type = 'tiezi'
			uni.getStorage({
				key:'tokens',
				success: (res) => {
					const refreshToken = res.data.refreshToken
					const accessToken = res.data.accessToken
					uni.request({
						url:'http://127.0.0.1:3007/userPersonal/toPaise',
						method:'POST',
						data:{
							acceptId,
							send_time,
							type
						},
						header: {
						  'content-type': 'application/json',
						  'Authorization': 'Bearer '+accessToken
						},
						success: (res) => {
							console.log(res)
							if(res.data.message=='身份验证失败'){
								refreshTokenGlobal(refreshToken).then(()=>{
									if(hasRefresh==false){
										hasRefresh=true
										toPaise(acceptId,index,true)
									}else{
										console.log('refreshToken fail')
									}
									
								}).catch((err)=>{
									console.log(err)
								})
							}else{
								tieArray.value[index].hasPaise = 1
								tieArray.value[index].like_count++
							}
							
						},
						fail: (err) => {
							console.log(err)
						}
					})
				}
			})
		}
		
		
	}
	function toStopPaise(acceptId,index,hasRefresh= false){
		if(!global.isLogin.value){
			uni.showModal({
				title:'登录提示',
				content:'用户尚未登录，请先登录再进行操作，是非前往登录？',
				success:(res)=>{
					if(res.confirm){
						uni.navigateTo({
							url:'../login/login'
						})
					}else{
						if(res.cancel){
							return
						}
					}
					
				},
				fail: (err) => {
					return
				}
			})
		}else{
			const send_time = Date.now()
			const type = 'tiezi'
			uni.getStorage({
				key:'tokens',
				success: (res) => {
					const refreshToken = res.data.refreshToken
					const accessToken = res.data.accessToken
					uni.request({
						url:'http://127.0.0.1:3007/userPersonal/toStopPaise',
						method:'POST',
						data:{
							acceptId
						},
						header: {
						  'content-type': 'application/json',
						  'Authorization': 'Bearer '+accessToken
						},
						success: (res) => {
							console.log(res)
							if(res.data.message=='身份验证失败'){
								refreshTokenGlobal(refreshToken).then(()=>{
									if(hasRefresh==false){
										hasRefresh=true
										toStopPaise(acceptId,index,true)
									}else{
										console.log('refreshToken fail')
									}
									
								}).catch((err)=>{
									console.log(err)
								})
							}else{
								tieArray.value[index].hasPaise = 0
								tieArray.value[index].like_count--
							}
							
						},
						fail: (err) => {
							console.log(err)
						}
					})
				}
			})
		}
	}
	function toStore(tieId,index,hasRefresh= false){
		if(!global.isLogin.value){
			uni.showModal({
				title:'登录提示',
				content:'用户尚未登录，请先登录再进行操作，是非前往登录？',
				success:(res)=>{
					if(res.confirm){
						uni.navigateTo({
							url:'../login/login'
						})
					}else{
						if(res.cancel){
							return
						}
					}
					
				},
				fail: (err) => {
					return
				}
			})
		}else{
			const store_time = Date.now()
			uni.getStorage({
				key:'tokens',
				success: (res) => {
					const refreshToken = res.data.refreshToken
					const accessToken = res.data.accessToken
					uni.request({
						url:'http://127.0.0.1:3007/userPersonal/toStore',
						method:'POST',
						data:{
							tieId,
							store_time
						},
						header: {
						  'content-type': 'application/json',
						  'Authorization': 'Bearer '+accessToken
						},
						success: (res) => {
							console.log(res)
							if(res.data.message=='身份验证失败'){
								refreshTokenGlobal(refreshToken).then(()=>{
									if(hasRefresh==false){
										hasRefresh=true
										toStore(tieId,index,hasRefresh)
									}else{
										console.log('refreshToken fail')
									}
									
								}).catch((err)=>{
									console.log(err)
								})
							}else{
								tieArray.value[index].hasStore=1
								tieArray.value[index].store_count++
							}
							
						},
						fail: (err) => {
							console.log(err)
						}
					})
				}
			})
		}
	}
	function toStopStore(tieId,index){
		if(!global.isLogin.value){
			uni.showModal({
				title:'登录提示',
				content:'用户尚未登录，请先登录再进行操作，是非前往登录？',
				success:(res)=>{
					if(res.confirm){
						uni.navigateTo({
							url:'../login/login'
						})
					}else{
						if(res.cancel){
							return
						}
					}
					
				},
				fail: (err) => {
					return
				}
			})
		}else{
			const store_time = Date.now()
			uni.getStorage({
				key:'tokens',
				success: (res) => {
					const refreshToken = res.data.refreshToken
					const accessToken = res.data.accessToken
					uni.request({
						url:'http://127.0.0.1:3007/userPersonal/toStopStore',
						method:'POST',
						data:{
							tieId
						},
						header: {
						  'content-type': 'application/json',
						  'Authorization': 'Bearer '+accessToken
						},
						success: (res) => {
							console.log(res)
							if(res.data.message=='身份验证失败'){
								refreshTokenGlobal(refreshToken).then(()=>{
									if(hasRefresh==false){
										hasRefresh=true
										toStore(tieId,index,hasRefresh)
									}else{
										console.log('refreshToken fail')
									}
									
								}).catch((err)=>{
									console.log(err)
								})
							}else{
								tieArray.value[index].hasStore=0
								tieArray.value[index].store_count--
							}
						},
						fail: (err) => {
							console.log(err)
						}
					})
				}
			})
		}
	}
	function navigateToSearch(e){
		uni.navigateTo({
			url:'../../tieBaPages/tieSearch/tieSearch'
		})
	}
	function navigateToPublish(e){
		uni.navigateTo({
			url:'../../tieBaPages/tiePublish/tiePublish'
		})
	}
	function clickLeft(){
		console.log(1)
	}
	function previewImage(images,index){
		console.log(images,index)
		uni.previewImage({
			current:index,
			urls:images
		})
		
	}
	function navigateToUserDetail(type,id){
		console.log(type,id)
		uni.navigateTo({
			url:`../../tieBaPages/userIndex/userIndex?type=${type}&id=${id}`
		})
	}
	function navigateToDetail(tieId){
		uni.navigateTo({
			url:`../../tieBaPages/tieDetail/tieDetail?tieId=${tieId}`
		})
	}
</script>

<style>
	.avatarBox image {
		border-radius: 100%;
	}
	.tieItem{
		background-color: #ffffff;
		width: 100%;
		border-bottom: solid 1rpx #dddddd;
		display: flex;
	}
	.avatarBox{}
	.avatarBox image{
		width: 90rpx;
		height: 90rpx;
		margin: 20rpx;
	}
	.infoBox{
		width: 80%;
	}
	.name_time{
		margin-top: 43rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding-right: 20rpx;
	}
	.name{
		font-size: 31rpx;
		color: #427eab;
		margin-right: 20rpx;
	}
	.time{
		font-size: 23rpx;
		color: #6e7082;
	}
	.content{
		margin-top: 30rpx;
		font-size: 30rpx;
		width: 70%;
		overflow: hidden;
		text-overflow: ellipsis;
		text-wrap: wrap;
		color: #292a2d;
		font-size: 30rpx;
		-webkit-box-orient: vertical;
		/* -webkit-line-clamp: 5; */
		min-height: 40rpx;
		max-height: 160rpx;
	}
	.table{
		width: max-content;
		margin-top: 10rpx;
		color: #0d469a;
		background-color: #b0c2e3;
		border-radius: 10rpx;
		padding-right: 10rpx;
		padding: 8rpx;
		font-size: 25rpx;
	}
	.buttons{
		margin-left: 300rpx;
		width: 300rpx;
		display: flex;
		justify-content: space-around;
	}
	.paiseBox{
		display: flex;
	}
	.paiseImgBox image{
		width: 30rpx;
		height: 30rpx;
		padding-right: 10rpx;
	}
	.paiseCount{
		font-size: 28rpx;
		color: #646464;
	}
	.paiseFont{
		font-size: 28rpx;
		color: #000000;
	}
	.commentsBox{
		display: flex;
	}
	.commentsImgBox image{
		width: 35rpx;
		height: 35rpx;
		padding-right: 10rpx;
	}
	.commentsCount{
		font-size: 28rpx;
		color: #000000;
	}
	.commentsFont{
		font-size: 28rpx;
		color: #000000;
	}
	.images{
		display: grid;
		grid-template-columns: repeat(2,1fr);
		grid-template-rows: 1;
		height: 200rpx;
		width: 540rpx;
		gap: -20rpx;
		overflow: hidden;
		margin-top: 10rpx;
	}
	.imageItem{
		/* margin-right: 30rpx; */
		height: 200rpx;
		width: 250rpx;
	}
	.imageItem image{
		height: 200rpx;
		width: 250rpx;
		border-radius: 20rpx;
	}
	.mov_view {
		  pointer-events:auto;
		  width: 80rpx;
		  height: 80rpx;
		  border-radius: 80rpx;
		  background-color: #447db9;
		  display: flex;
		  justify-content: center;
		  align-items: center;
		  position: fixed;
		  background: linear-gradient(45deg, #17dbeb, #548bfa);
	}
	movable-area{
		text-align: justify;
		width: 100%;
		height: 100%;
	}
	.mov_img image{
		padding-top: 10rpx;
		width: 65rpx;
		height: 65rpx;
	}
</style>
