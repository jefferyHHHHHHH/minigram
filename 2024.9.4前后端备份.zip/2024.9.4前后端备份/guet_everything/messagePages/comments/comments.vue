<template>
	<view>
		<uni-nav-bar title="回复我的" statusBar='true' backgroundColor='#447db9' color='#eaebeb' fixed='true' left-icon="back" @clickLeft="navigateToBack" leftWidth='80'></uni-nav-bar>
	</view>
</template>

<script setup>
	
</script>

<style>
	       
</style>
