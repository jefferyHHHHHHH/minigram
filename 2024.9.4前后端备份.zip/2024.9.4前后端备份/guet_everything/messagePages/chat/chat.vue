<template>
	<view>
		<uni-nav-bar title="聊天" statusBar='true' backgroundColor='#447db9' color='#eaebeb' fixed='true' left-icon="back" @clickLeft="navigateToBack" leftWidth='80'></uni-nav-bar>
		<view class="tabbar">
			<view v-if="hasChoseOption1" class="chosenTabbarItem boderRight">
				<view class="tabbarIcon1">
					<image  src="../../static/最近消息.png"></image>
				</view>
				<view class="chosenTabbarFont">最近消息</view>
			</view>
			<view v-else class="tabbarItem boderRight" @click="toChoseOption1">
				<view class="tabbarIcon1 ">
					<image src="../../static/最近消息 (1).png"></image>
				</view>
				<view class="tabbarFont">最近消息</view>
			</view>
			<view v-if="hasChoseOption2" class="chosenTabbarItem">
				<view class="tabbarIcon">
					<image src="../../static/邀请好友.png" ></image>
				</view>
				<view class="chosenTabbarFont">朋友列表</view>
			</view>
			<view  v-else class="tabbarItem" @click="toChoseOption2">
				<view class="tabbarIcon">
					<image src="../../static/邀请好友 (1).png" ></image>
				</view>
				<view class="tabbarFont">朋友列表</view>
			</view>
		</view>
		<view class="messages" v-if="hasChoseOption1">
			<view class="messageItem" v-for="(messageItem,index) in messageList">
				<view class="avatarBox">
					<image :src="messageItem.avatarUrl"></image>
				</view>
				<view class="detailBox">
					<view class="left_right marginBottom">
						<view class="name">{{messageItem.nickname}}</view>
						<view class="time">{{messageItem.time}}</view>
					</view>
					<view class="left_right">
						<view class="messageContent">{{messageItem.message}}</view>
						<view class="messageManageIcon">
							<image src="../../static/_text_align_justify.png"></image>
						</view>
					</view>
				</view>
			</view>
		</view>
		<view class="friendsList" v-if="hasChoseOption2">
			<view class="titile">朋友</view>
			<view class="tip" v-if="friendsList.length==0">你还没有朋友噢，快去交个朋友吧</view>
			<view class="list" v-for="(friendItem,index) in friendsList">
				<view class="listItem">
					<view class="chatAvatar">
						<image :src="friendItem.avatarUrl"></image>
					</view>
					<view class="chatName">{{friendItem.nickname}}</view>
				</view>
			</view>
			<!-- <view class="titile">群聊</view>
			<view class="list" v-for="(groupItem,index) in groupList">
				<view class="listItem">
					<view class="chatAvatar">
						<image :src="groupItem.groupAvatar"></image>
					</view>
					<view class="chatName">{{groupItem.groupName}}</view>
				</view>
			</view> -->
		</view>
	</view>
</template>

<script setup>
	import {ref,getCurrentInstance} from 'vue'
	import {onLoad} from "@dcloudio/uni-app"
	const {
				appContext: {
					config: {
						globalProperties: global
				}
					}
			} = getCurrentInstance();
	const goEasy = global.goEasy
	var hasChoseOption2 = ref(false)
	var hasChoseOption1 = ref(true)
	var currentUser = ref('')
	const actionPopup= ref({
	  conversation: null,
	  visible: false
	})
	var conversations = []
	var messageList = [
		{
			avatarUrl:'../../static/backgroundIMG.png',
			nickname:'胡图图',
			id:'123123',
			message:'我：你吃瘪asfasdfasdfasdfasdfasfasdfasdfasdfasdfasdfasfasdfasdfasdfasfasdfasdfasdfadsfas',
			time:'2024/9/3 11:36'
		},
		{
			avatarUrl:'../../static/backgroundIMG.png',
			nickname:'胡图图',
			id:'123123',
			message:'我：你吃瘪',
			time:'2024/9/3 11:36'
		},
		{
			avatarUrl:'../../static/backgroundIMG.png',
			nickname:'胡图图',
			id:'123123',
			message:'我：你吃瘪',
			time:'2024/9/3 11:36'
		},
		{
			avatarUrl:'../../static/backgroundIMG.png',
			nickname:'胡图图',
			id:'123123',
			message:'我：你吃瘪',
			time:'2024/9/3 11:36'
		},
		{
			avatarUrl:'../../static/backgroundIMG.png',
			nickname:'胡图图',
			id:'123123',
			message:'我：你吃瘪',
			time:'2024/9/3 11:36'
		},
		{
			avatarUrl:'../../static/backgroundIMG.png',
			nickname:'胡图图',
			id:'123123',
			message:'我：你吃瘪',
			time:'2024/9/3 11:36'
		},
		{
			avatarUrl:'../../static/backgroundIMG.png',
			nickname:'胡图图',
			id:'123123',
			message:'我：你吃瘪',
			time:'2024/9/3 11:36'
		},
		{
			avatarUrl:'../../static/backgroundIMG.png',
			nickname:'胡图图',
			id:'123123',
			message:'我：你吃瘪',
			time:'2024/9/3 11:36'
		},
		{
			avatarUrl:'../../static/backgroundIMG.png',
			nickname:'胡图图',
			id:'123123',
			message:'我：你吃瘪',
			time:'2024/9/3 11:36'
		},
		{
			avatarUrl:'../../static/backgroundIMG.png',
			nickname:'胡图图',
			id:'123123',
			message:'我：你吃瘪',
			time:'2024/9/3 11:36'
		},
		{
			avatarUrl:'../../static/backgroundIMG.png',
			nickname:'胡图图',
			id:'123123',
			message:'我：你吃瘪',
			time:'2024/9/3 11:36'
		},
		{
			avatarUrl:'../../static/backgroundIMG.png',
			nickname:'胡图图',
			id:'123123',
			message:'我：你吃瘪',
			time:'2024/9/3 11:36'
		},
		{
			avatarUrl:'../../static/backgroundIMG.png',
			nickname:'胡图图',
			id:'123123',
			message:'我：你吃瘪',
			time:'2024/9/3 11:36'
		}
	]
	var groupList = [
		{
			groupId:123,
			groupAvatar:'../../static/backgroundIMG.png',
			groupName:"金地花园"
	
		},
		{
			groupId:123,
			groupAvatar:'../../static/backgroundIMG.png',
			groupName:"金地花园"
		},
		{
			groupId:123,
			groupAvatar:'../../static/backgroundIMG.png',
			groupName:"金地花园"
		},
		{
			groupId:123,
			groupAvatar:'../../static/backgroundIMG.png',
			groupName:"金地花园"
		},
		{
			groupId:123,
			groupAvatar:'../../static/backgroundIMG.png',
			groupName:"金地花园"
		},
	]
	var friendsList = ref([])
	// var friendsList = [
	// 	{
	// 		id:'123',
	// 		avatarUrl:'../../static/backgroundIMG.png',
	// 		nickname:'胡图图'
	// 	},
	// 	{
	// 		id:'123',
	// 		avatarUrl:'../../static/backgroundIMG.png',
	// 		nickname:'胡图图'
	// 	},
	// 	{
	// 		id:'123',
	// 		avatarUrl:'../../static/backgroundIMG.png',
	// 		nickname:'胡图图'
	// 	},
	// 	{
	// 		id:'123',
	// 		avatarUrl:'../../static/backgroundIMG.png',
	// 		nickname:'胡图图'
	// 	},
	// 	{
	// 		id:'123',
	// 		avatarUrl:'../../static/backgroundIMG.png',
	// 		nickname:'胡图图'
	// 	},
	// 	{
	// 		id:'123',
	// 		avatarUrl:'../../static/backgroundIMG.png',
	// 		nickname:'胡图图'
	// 	},
	// 	{
	// 		id:'123',
	// 		avatarUrl:'../../static/backgroundIMG.png',
	// 		nickname:'胡图图'
	// 	},
	// 	{
	// 		id:'123',
	// 		avatarUrl:'../../static/backgroundIMG.png',
	// 		nickname:'胡图图'
	// 	},
	// 	{
	// 		id:'123',
	// 		avatarUrl:'../../static/backgroundIMG.png',
	// 		nickname:'胡图图'
	// 	},
	// 	{
	// 		id:'123',
	// 		avatarUrl:'../../static/backgroundIMG.png',
	// 		nickname:'胡图图'
	// 	},
	// 	{
	// 		id:'123',
	// 		avatarUrl:'../../static/backgroundIMG.png',
	// 		nickname:'胡图图'
	// 	},
	// ]
	function toChoseOption1(){
		hasChoseOption1.value = true
		hasChoseOption2.value = false
	}
	function toChoseOption2(){
		hasChoseOption2.value = true
		hasChoseOption1.value = false
	}
	function navigateToBack (){
		uni.navigateBack()
	}
	function connectGoEasy() {
        uni.showLoading();
        goEasy.connect({
          id: currentUser.value.id,
          data: {
            name: currentUser.value.name,
            avatar: currentUser.value.avatar
          },
          onSuccess: () => {
            console.log('GoEasy connect successfully.')
          },
          onFailed: (error) => {
            console.log('Failed to connect GoEasy, code:' + error.code + ',error:' + error.content);
          },
          onProgress: (attempts) => {
            console.log('GoEasy is connecting', attempts);
          }
        });
      }
	function loadConversations() {
        goEasy.im.latestConversations({
          onSuccess: (result) => {
            uni.hideLoading();
            let content = result.content;
            renderConversations(content);
            let unreadTotal = content.unreadTotal;
            if(unreadTotal > 0) {
              uni.setTabBarBadge({
                index: 0,
                text: unreadTotal.toString()
              });
            }else{
              uni.removeTabBarBadge({index: 0});
            }
          },
          onFailed: (error) => {
            uni.hideLoading();
            console.log('获取最新会话列表失败, error:', error);
          }
        });
      }
	  function renderConversations(content) {
        conversations = content.conversations;
      }
	  function subscribeGroup() {
	    let groups = [
			{
            id: 'group-a42b-47b2-bb1e-15e0f5f9a19a',
            name: '小程序交流群',
            avatar: '/static/images/wx.png',
            userList: [
                '08c0a6ec-a42b-47b2-bb1e-15e0f5f9a19a',
                '3bb179af-bcc5-4fe0-9dac-c05688484649',
                'fdee46b0-4b01-4590-bdba-6586d7617f95',
                '33c3693b-dbb0-4bc9-99c6-fa77b9eb763f',
            ],
			},
			{
            id: 'group-4b01-4590-bdba-6586d7617f95',
            name: 'UniApp交流群',
            avatar: '/static/images/uniapp.png',
            userList: [
                '08c0a6ec-a42b-47b2-bb1e-15e0f5f9a19a',
                'fdee46b0-4b01-4590-bdba-6586d7617f95',
                '33c3693b-dbb0-4bc9-99c6-fa77b9eb763f',
            ],
			},
			{
            id: 'group-dbb0-4bc9-99c6-fa77b9eb763f',
            name: 'GoEasy交流群',
            avatar: '/static/images/goeasy.jpeg',
            userList: ['08c0a6ec-a42b-47b2-bb1e-15e0f5f9a19a', '3bb179af-bcc5-4fe0-9dac-c05688484649'],
			},
		]
	    let groupIds = groups.map(item => item.id);
	    goEasy.im.subscribeGroup({
	      groupIds: groupIds,
	      onSuccess: function () {
	        console.log('订阅群消息成功');
	      },
	      onFailed: function (error) {
	        console.log('订阅群消息失败:', error);
	      }
	    });
	  }
	  function topConversation() {  //会话置顶
        actionPopup.visible = false;
        let conversation = actionPopup.conversation;
        let description = conversation.top ? '取消置顶' : '置顶';
        goEasy.im.topConversation({
          conversation: conversation,
          top: !conversation.top,
          onSuccess: function () {
            uni.showToast({
              title: description + '成功',
              icon: 'none'
            });
          },
          onFailed: function (error) {
            console.log(description, '失败：', error);
          }
        });
      }
	  function deleteConversation() {
        uni.showModal({
          content: '确认删除这条会话吗？',
          success: (res) => {
            if (res.confirm) {
              let conversation = actionPopup.conversation;
              actionPopup.visible = false;
              goEasy.im.removeConversation({
                conversation: conversation,
                onSuccess: function () {
                  console.log('删除会话成功');
                },
                onFailed: function (error) {
                  console.log(error);
                },
              });
            } else {
              actionPopup.visible = false;
            }
          },
        })
      }
	  function chat(conversation) {
        let path = conversation.type === GoEasy.IM_SCENE.PRIVATE
          ? './privateChat?to=' + conversation.userId
          : './groupChat?to=' + conversation.groupId;
        uni.navigateTo({ url: path });
      }
	  function getFriends(hasRefresh=false){
		  if(!global.isLogin.value){
		  	showLoginTip('../../pages/login/login')
		  }else{
		  	const type = 'tiezi'
		  	uni.getStorage({
		  		key:'tokens',
		  		success: (res) => {
		  			const refreshToken = res.data.refreshToken
		  			const accessToken = res.data.accessToken
		  			uni.request({
		  				url:'http://127.0.0.1:3007/userPersonal/getFriends',
		  				method:'GET',
		  				header: {
		  				  'content-type': 'application/json',
		  				  'Authorization': 'Bearer '+accessToken
		  				},
		  				success: (res) => {
		  					console.log(res)
		  					if(res.data.message=='身份验证失败'){
		  						refreshTokenGlobal(refreshToken).then(()=>{
		  							if(hasRefresh==false){
		  								hasRefresh=true
		  								getFriends(hasRefresh)
		  							}else{
		  								console.log('refreshToken fail')
		  							}
		  							
		  						}).catch((err)=>{
		  							console.log(err)
									return
		  						})
		  					}else{
		  						friendsList.value = res.data
		  					}
		  					
		  				},
		  				fail: (err) => {
		  					console.log(err)
		  				}
		  			})
		  		}
		  	})
		  }
	  }
	  onLoad(()=>{
		  getFriends()
	  })
</script>

<style>
	.tabbar {
		position: fixed;
		display: flex;
		width: 100%;
		align-items: center;
		border-bottom: 1rpx #eaeaea solid;
	}
	.chosenTabbarItem {
		width: 50%;
		display: flex;
		justify-content: center;
		align-items: center;
		background-color: #ffffff;
		height: 70rpx;
	}
	.tabbarItem{
		width: 50%;
		display: flex;
		justify-content: center;
		align-items: center;
		background-color: #d1d1d1;
		height: 70rpx;
	}
	.tabbarIcon1{
		padding-top: 10rpx;
	}
	.tabbarIcon1 image{
		width: 45rpx;
		height: 45rpx;
	}
	.tabbarIcon image{
		width: 50rpx;
		height: 50rpx;
	}
	.chosenTabbarFont {
		margin-left: 10rpx;
		font-size: 26rpx;
		color: #515151;
		font-weight: 600;
	}
	.tabbarFont {
		margin-left: 10rpx;
		font-size: 26rpx;
		color: #737373;
	}
	.boderRight {
		border-right: #bcbcbc solid 2rpx;
	}
	.messages {
		margin-top: 80rpx;
	}
	.messageItem {
		padding: 25rpx 40rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		border-bottom: #eaeaea 1rpx solid;
		background-color: #ffffff;
	}
	.avatarBox image{
		width: 90rpx;
		height: 90rpx;
		border-radius: 100%;
	}
	.left_right {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	.detailBox {
		width: 540rpx;
	}
	.name {
		font-size: 29rpx;
		color: #000000;
		overflow: hidden;
	}
	.time {
		font-size: 25rpx;
		color: #737373;
	}
	.messageContent {
		color: #515151;
		font-size: 27rpx;
		overflow: hidden;
	}
	.messageManageIcon image{
		width:38rpx;
		height:38rpx;
	}
	.marginBottom {
		margin-bottom: 13rpx;
	}
	.friendsList {
		margin-top: 80rpx;
	}
	.titile {
		padding: 15rpx 0 15rpx 30rpx;
		font-size: 27rpx;
		color: #737373;
		background-color: #f9f9f9;
		border-bottom: solid 1rpx #eaeaea;
	}
	.list {
	}
	.listItem {
		border-bottom: #eaeaea 1rpx solid;
		background-color: #ffffff;
		display: flex;
		align-items: center;
		padding: 25rpx 40rpx;
	}
	.chatAvatar image{
		width: 90rpx;
		height: 90rpx;
		border-radius: 100%;
	}
	.chatName {
		font-size: 30rpx;
		color: #000000;
		margin-left: 40rpx;
		font-weight: 500;
	}
	.tip {
		padding-top: 15rpx;
		text-align: center;
		color: #737373;
		font-size: 26rpx;
	}
</style>
