<template>
	<view>
	    <view class="nav-bar" :style="{height: navBarHeight, opacity: navBarOpacity,backgroundColor: backgroundColor}">
			 <view v-if="haveTitle" class="title" :style="{ color: fontColor }">{{ title }}</view>
		</view>
	    <view class="leftArrow" :style="{top: LeftArrowTop}" @click="navigateBack">
	      <image src="../../static/左箭头.png"></image>
	    </view>
	  </view>
</template>

<script>
	import { ref, computed, onMounted } from 'vue';
	import { getCurrentInstance } from 'vue';
	export default {
		props: {
			toBack:{
				type:Boolean,
				default:false
			},
			toHome:{
				type:Boolean,
				default:false
			},
			haveTitle:{
				type:Boolean,
				default:true
			},
			title:{
				type:String,
				default:"导航栏"
			},
			backgroundColor:{
				type:String,
				default:"#000000"
			},
			fontColor:{
				type:String,
				default:"#ffffff"
			},
			opacity:{
				type:Number,
				default:1
			}
		},
		methods: {
			navigateBack() {
			  uni.navigateBack();
			},
		},
		  setup(props) {
			
		    const instance = getCurrentInstance();
		    const global = instance.appContext.config.globalProperties;
		
		    const navBarHeight = `${global.Custom.bottom * 2 + 15}rpx`;
		    const LeftArrowTop = `${global.Custom.height * 2}rpx`;
		    // const scrollTop = ref(0);
		    // const navBarOpacity = computed(() => {
		    //   return scrollTop.value > 200 ? 1 : scrollTop.value / 200;
		    // });
		
		    // const scrollHeight = computed(() => {
		    //   return `${global.safeArea.bottom * 2}rpx`;
		    // });
		
		    
		
		    // onMounted(() => {
		    //   onPageScroll((e) => {
		    //     scrollTop.value = e.scrollTop;
		    //   });
		    // });
		
		    return {
			  ...props,
		      navBarHeight,
		      LeftArrowTop,
		      navBarOpacity,
		      navigateBack,
		      scrollHeight
		    };
		  }
	}
</script>

<style>
	.nav-bar{
		/* background-color: #092438; */
		background-color: #000000; 
		position: fixed;
		width: 100%;
		top: 0;
		z-index: 999;
	}
	.leftArrow{
		position: fixed;
		left: 20rpx;
		z-index: 2000;
	}
	.leftArrow image{
		width: 50rpx;
		height: 50rpx;
	}
	.scrollView {
		width: 100%;
		background-color: aliceblue;
		height: 1500rpx;
	}
	.red{
		height: 300rpx;
		width: 100%;
		background-color: darkblue;
	}
	.yellow{
		height: 300rpx;
		width: 100%;
		background-color: darkcyan;
	}
</style>