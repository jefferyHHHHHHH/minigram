// #ifndef VUE3
import Vue from 'vue'
Vue.prototype.$appname = "guet_everything"
import App from './App'
Vue.config.productionTip = false
App.mpType = 'app'
const app = new Vue({
    ...App
})
app.$mount()
// #endif

// #ifdef VUE3
import { createSSRApp } from 'vue'
import utls from './common';
import App from './App.vue'
import GoEasy from 'goeasy'
const app = createApp(App)
console.log(utls)
export function createApp() {
	const app = createSSRApp(App)
	app.provide('refreshTokenGlobal',utls.glbFunction.refreshTokenGlobal);
	app.provide('showLoginTip',utls.glbFunction.showLoginTip)
	app.config.globalProperties.goeasy = GoEasy.getInstance({
		host:"hangzhou.goeasy.io",
		appkey:"BC-5ac5cd399013484cb295ab113e6a97b4",
		modules:['im']
	})
	//	或者可以使用uni.挂载带全局
	uni.$u = 'wtuuuuuuu'
	return {
		app
	}
}
// #endif