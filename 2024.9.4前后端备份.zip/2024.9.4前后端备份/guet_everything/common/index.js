import refreshTokenGlobal from './libs/refreshTokenGlobal.js'
import showLoginTip from './libs/showLoginTip.js'
const glbFunction = {
	refreshTokenGlobal,
	showLoginTip
}

export default {
	glbFunction
}