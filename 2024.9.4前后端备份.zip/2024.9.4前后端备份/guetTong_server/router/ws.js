const express = require('express')
const expressWs = require('express-ws')
const wsHandler = require('../router_handler/ws.js')
const router = express.Router()
expressWs(router)

router.ws('chat', wsHandler.chat)

module.exports = router