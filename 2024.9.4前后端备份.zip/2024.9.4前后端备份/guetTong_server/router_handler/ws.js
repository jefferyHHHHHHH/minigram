const { query, response } = require('express')
const db = require('../db/index')
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')
const config = require('../config')
const axios = require('axios')
const { gettimeago } = require('../methods/gettimeago')

exports.chat = (ws, req) => {
    ws.send('连接成功！')
    ws.on('message', function (msg) {
        console.log('on message')
    })
    ws.on('close', function (msg) {
        console.log('close chat')
    })
}