const { query } = require('express')
const db = require('../db/index')
const bcrypt = require('bcryptjs')
// const bcryptjs = require('bcrypt')
const jwt = require('jsonwebtoken')
const config = require('../config')
const { gettimeago } = require('../methods/gettimeago')
exports.updateUserInfo = (req, res) => {
    const sql = 'update * from userinfo set ? where openid =?'
    const newUserInfo = req.body
    const openid = req.auth.openid
    db.query(sql, [newUserInfo, openid], (err, results) => {
        if (err) {
            console.log(err)
            return res.cc(err)
        }
        if (results.affectedRows === 1) return res.send({
            status: 200,
            message: '数据修改成功！'
        })

    })
}
exports.updatePassword = (req, res) => {
    const openid = req.auth.openid
    const oldpassword = req.body.oldpassword
    const newpassword = req.body.newpassword
    const sql = 'select * from userinfo where openid=?'
    db.query(sql, openid, (err, results) => {
        if (err) return res.cc(err)
        const compareResult = bcrypt.compareSync(oldpassword, results[0].password)
        if (!compareResult) return res.cc('密码错误！')
        const updateSql = 'update  from userinfo  '
    })
}
exports.getUserInfo = (req, res) => {
    const sql = 'select * from userinfo where openid=?'
    console.log(req.query)
    openid = req.query.openid
    db.query(sql, openid, (err, results) => {
        if (err) return res.cc("找不到对应用户的信息" + openid)
        console.log(results)
        return res.send({
            status: 202,
            data: results[0],
            message: '获取相应用户信息成功！'
        })
    })
}
exports.autoLogin = (req, res) => {
    const openid = req.auth.openid
    const sql = 'select * from userinfo where openid = ?'
    db.query(sql, openid, (err, results) => {
        if (err) return res.cc(err)
        const userInfo = {
            avatarUrl: results[0].avatarUrl,
            gender: results[0].gender,
            nickname: results[0].nickname,
            major: results[0].major,
            userId: results[0].userId
        }
        return res.send({
            status: 202,
            userInfo: userInfo,
            message: '自动登录成功！'
        })
    })
}
exports.tieziPublish = (req, res) => {
    const tieInfo = req.body.tieInfo
    tieInfo.authorId = req.auth.openid
    if (tieInfo.images.length === 0) {
        tieInfo.images = null
    } else {
        tieInfo.images = JSON.stringify(tieInfo.images)
    }
    if (tieInfo.videos.length === 0) {
        tieInfo.videos = null
    } else {
        tieInfo.videos = JSON.stringify(tieInfo.videos)
    }
    console.log(tieInfo)
    const querySql = 'INSERT INTO tiearray (authorId,publish_time,content,tag,images,videos) VALUES (?,?,?,?,?,?)'
    db.query(querySql, [tieInfo.authorId, tieInfo.publish_time, tieInfo.content, tieInfo.tag, tieInfo.images, tieInfo.videos], (err, results) => {
        console.log(results)
        console.log(err)
        if (err) return res.send({ message: '插入帖子信息错误' })
        if (results.affectedRows === 1)
            return res.send({
                status: 202,
                success: true,
            })
        return res.send({ message: '插入帖子失败' })
    })
}
exports.toPaise = (req, res) => {
    console.log(req.body, req.auth.openid)
    const sendId = req.auth.openid
    const acceptId = req.body.acceptId
    const send_time = req.body.send_time
    const type = req.body.type
    const sql = 'INSERT INTO paisearray (sendId,acceptId,send_time,type) VALUES (?,?,?,?)'
    db.query(sql, [sendId, acceptId, send_time, type], (err, results) => {
        if (err) return res.cc(err)
        console.log(results)
        res.send({
            message: '点赞成功！',
            status: 200
        })
    })
}
exports.toStopPaise = (req, res) => {
    console.log(req.body, req.auth.openid)
    const sendId = req.auth.openid
    const acceptId = req.body.acceptId
    const type = req.body.type
    const sql = 'DELETE FROM paisearray WHERE sendId = ? AND acceptId = ? AND type = ? '
    db.query(sql, [sendId, acceptId, type], (err, results) => {
        if (err) return res.cc(err)
        console.log(results)
        res.send({
            message: '取消点赞成功！',
            status: 200
        })
    })
}
exports.toStore = (req, res) => {
    const tieId = req.body.tieId
    const storerId = req.auth.openid
    const store_time = req.body.store_time
    const sql = 'INSERT INTO storelist (tieId,storerId,store_time) VALUES (?,?,?)'
    db.query(sql, [tieId, storerId, store_time], (err, results) => {
        if (err) return res.cc(err)
        console.log(results)
        res.send({
            message: '收藏成功！',
            status: 200
        })
    })
}
exports.toStopStore = (req, res) => {
    const tieId = req.body.tieId
    const storerId = req.auth.openid
    const sql = 'DELETE FROM storelist WHERE tieId = ? AND storerId = ? '
    db.query(sql, [tieId, storerId], (err, results) => {
        if (err) return res.cc(err)
        console.log(results)
        res.send({
            message: '取消收藏成功！',
            status: 200
        })
    })

}
exports.visitUserIndex = (req, res) => {
    const openid = req.auth.openid
    var sql = '';
    const id = req.query.id;
    if (req.query.type == 'tiezi') {
        sql = `SELECT
        u.nickname,
        u.avatarUrl,
        u.gender,
        u.major,
        t2.tieId,
        t2.content,
        t2.view_count,
        t2.tag,
        t2.images,
        t2.videos,
        t2.publish_time,
        COUNT(DISTINCT CASE WHEN p.sendId = '${openid}' THEN p.paiseId END) AS hasPaise,
        COUNT(DISTINCT s.storeId) AS store_count,
        COUNT(DISTINCT c.commentId) AS comment_count,
        COUNT(DISTINCT p.paiseId) AS like_count,
        COUNT(DISTINCT CASE WHEN s.storerId = '${openid}' THEN s.storeId END) AS hasStore
        FROM
         tiearray t
        LEFT JOIN
         userInfo u ON t.authorId = u.openid
        LEFT JOIN
         tiearray t2 ON t.authorId = t2.authorId
        LEFT JOIN
        paisearray p ON t2.tieId = p.acceptId
        LEFT JOIN
        storelist s ON t2.tieId = s.tieId
        LEFT JOIN
        commentlist c ON c.tieId = t2.tieId
        WHERE
         t.tieId = ?
         GROUP BY 
        t2.tieId,u.nickname,u.avatarUrl,u.gender,u.major,t2.content,t2.view_count,t2.tag,t2.images,t2.videos,t2.publish_time
        ORDER BY
            t2.tieId DESC`;
    } else if (req.query.type == 'comment') {
        sql = `SELECT
        u.nickname,
        u.avatarUrl,
        u.gender,
        u.major,
        t.tieId,
        t.content,
        t.view_count,
        t.tag,
        t.images,
        t.videos,
        t.publish_time,
        COUNT(DISTINCT CASE WHEN p.sendId = '${openid}' THEN p.paiseId END) AS hasPaise,
        COUNT(DISTINCT s.storeId) AS store_count,
        COUNT(DISTINCT p.paiseId) AS like_count,
        COUNT(DISTINCT c.commentId) AS comment_count,
        COUNT(DISTINCT CASE WHEN s.storerId = '${openid}' THEN s.storeId END) AS hasStore
        FROM
         comment c
        JOIN
         userInfo u ON c.openid = u.openid
        LEFT JOIN
         tiearray t ON t.authorId = c.openid
        LEFT JOIN
        paisearray p ON t.tieId = p.acceptId
        LEFT JOIN
        storelist s ON t.tieId = s.tieId
        LEFT JOIN
        commentlist c ON c.tieId = t.tieId
        WHERE
         c.openid = ?
        GROUP BY 
        t.tieId,u.nickname,u.avatarUrl,u.gender,u.major,t.content,t.view_count,t.tag,t.images,t.videos,t.publish_time
        ORDER BY
            t.tieId DESC`;
    } else {
        res.cc('请求中type未知');
    }
    db.query(sql, [id], (err, results) => {
        if (err) return res.cc(err)
        try {
            const userInfo = {
                avatarUrl: results[0].avatarUrl,
                gender: results[0].gender,
                major: results[0].major,
                nickname: results[0].nickname
            }
            const tieArray = results.map(obj => {
                const { avatarUrl, gender, major, nickname, ...remainTie } = obj
                return remainTie
            })
            tieArray.forEach(tieItem => {
                tieItem.timeAgo = gettimeago(tieItem.publish_time)
                if (tieItem.images) {
                    tieItem.images = JSON.parse(tieItem.images)
                }
                if (tieItem.videos) {
                    tieItem.videos = JSON.parse(tieItem.videos)
                }
            });
            userInfo.tieArray = tieArray
            res.send(userInfo)
        } catch (err) {
            res.cc(err)
        }

    })
    // 执行SQL查询的代码应该在这里，使用参数化查询防止SQL注入
};
exports.showStoreList = async (req, res) => {
    const openid = req.auth.openid
    console.log(req.query)
    const id = req.query.id
    const type = req.query.type
    const sql = `SELECT
        u.avatarUrl,
        u.nickname,
        u.gender,
        t.tieId,
        t.content,
        t.images,
        t.videos,
        t.tag,
        t.publish_time,
        COUNT(DISTINCT CASE WHEN p.sendId = '${openid}' THEN p.paiseId END) AS hasPaise,
        COUNT(DISTINCT s2.storeId) AS store_count,
        COUNT(DISTINCT c.commentId) AS comment_count,
        COUNT(DISTINCT p.paiseId) AS like_count,
        COUNT(DISTINCT CASE WHEN s2.storerId = '${openid}' THEN s2.storeId END) AS hasStore
        FROM
        storelist s
        LEFT JOIN
        tiearray t ON s.tieId = t.tieId
        LEFT JOIN
        userInfo u ON t.authorId = u.openid
        LEFT JOIN
        commentlist c ON c.tieId = t.tieId
        LEFT JOIN
        storelist s2 ON t.tieId = s2.tieId
        LEFT JOIN
        paisearray p ON t.tieId = p.acceptId
        WHERE
        s.storerId = ?
        GROUP BY 
        t.tieId, u.nickname, u.avatarUrl, t.content, t.images, t.videos, t.publish_time, t.tag
        ORDER BY
            t.tieId DESC`;
    var storerId = ''
    if (type == 'tiezi') {
        await db.query('SELECT authorId FROM tiearray WHERE tieId = ?', [id], async (err, results) => {
            if (err) return res.cc(err)
            // console.log(results[0].authorId)
            storerId = results[0].authorId
            db.query(sql, [storerId], (err, results) => {
                if (err) return res.cc(err)
                res.send(results)
            })
        })
    } else {
        if (type == 'comment') {
            await db.query('SELECT openid FROM commentlist WHERE commentId = ?', [id], async (err, results) => {
                if (err) return res.cc(err)
                console.log(result[0])
                storerId = results[0].openid
                db.query(sql, [storerId], (err, results) => {
                    if (err) return res.cc(err)
                    res.send(results)
                })
            })
        } else {
            return res.cc('获取收藏列表时请求的type发生错误')
        }
    }

}
exports.toFocus = (req, res) => {
    console.log(req.body)
    const { type, focus_time, id } = req.body
    const focuserId = req.auth.openid
    const sql = 'INSERT INTO focuslist (focuserId,beFocusId,focus_time) VALUES (?,?,?)'
    if (type == 'tiezi') {
        const getBeFocusId = 'SELECT authorId FROM tiearray WHERE tieId = ?'
        db.query(getBeFocusId, [id], (err, results) => {
            if (err) return res.cc(err)
            console.log(results[0].authorId)
            const beFocusId = results[0].authorId
            db.query(sql, [focuserId, beFocusId, focus_time], (err, results) => {
                if (err) return res.cc(err)
                res.send(results)
            })
        })
    } else if (type == 'comment') {
        const getBeFocusId = 'SELECT openid FROM commentlist WHERE commentId = ?'
        db.query(getBeFocusId, [id], (err, results) => {
            if (err) return res.cc(err)
            const beFocusId = results[0].openid
            db.query(sql, [focuserId, beFocusId, focus_time], (err, results) => {
                if (err) return res.cc(err)
                res.send(results)
            })
        })


    }
}
exports.toCancelFocus = (req, res) => {
    console.log(req.body)
    const { type, id } = req.body
    const focuserId = req.auth.openid
    const sql = 'DELETE FROM focuslist WHERE focuserId = ? AND beFocusId = ?'
    if (type == 'tiezi') {
        const getBeFocusId = 'SELECT authorId FROM tiearray WHERE tieId = ?'
        db.query(getBeFocusId, [id], (err, results) => {
            if (err) return res.cc(err)
            console.log(results[0].authorId)
            const beFocusId = results[0].authorId
            db.query(sql, [focuserId, beFocusId], (err, results) => {
                if (err) return res.cc(err)
                res.send(results)
            })
        })
    } else if (type == 'comment') {
        const getBeFocusId = 'SELECT openid FROM commentlist WHERE commentId = ?'
        db.query(getBeFocusId, [id], (err, results) => {
            if (err) return res.cc(err)
            const beFocusId = results[0].openid
            db.query(sql, [focuserId, beFocusId], (err, results) => {
                if (err) return res.cc(err)
                res.send(results)
            })
        })


    }
}
exports.getFriends = (req, res) => {
    const openid = req.auth.openid
    const sql = `SELECT
    u.userId,
    u.avatarUrl,
    u.nickname
FROM
    userinfo u
JOIN
    focuslist f1 ON u.openid = f1.beFocusId
JOIN
    focuslist f2 ON u.openid = f2.focuserId
WHERE
    f1.focuserId = ? AND f2.beFocusId = ?
GROUP BY
    u.userId,u.avatarUrl,u.nickname`
    db.query(sql, [openid, openid], (err, results) => {
        if (err) return res.cc(err)
        res.send(results)
    })
}

//t.tieId,u.nickname,u.avatarUrl,t.content,t.images,t.videos,t.publish_time,t.tag
