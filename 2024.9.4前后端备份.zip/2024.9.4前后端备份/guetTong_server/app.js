const express = require('express')
const cors = require('cors')
const userRouter = require('./router/user')
const userPersonal = require('./router/userPersonal')
const wsRouter = require('./router/ws')
const joi = require('joi')
const app = express()
const { expressjwt } = require('express-jwt')
const config = require('./config')
const expressWs = require('express-ws')

expressWs(app)

app.use(express.urlencoded({ extended: false }))
app.use((req, res, next) => {
    res.cc = function (err, status = 1) {
        res.send({
            status,
            message: err instanceof Error ? err.message : err
        })
    }
    next()
})
app.use(express.json())
app.use(expressjwt({ secret: config.jwtSecreKey, algorithms: ['HS256'] }).unless({ path: [/^\/user\//] }))
app.use('/user', userRouter)
app.use('/userPersonal', userPersonal)
app.use('/ws', wsRouter)
app.use(cors())
app.use((err, req, res, next) => {
    if (err instanceof joi.ValidationError) return res.cc(err)
    if (err.name === 'UnauthorizedError') return res.send({
        message: '身份验证失败',
        status: 401
    })
    return res.send({
        message: '未知错误',
        errmsg: err
    })
})


app.listen(3007, () => {
    console.log('guidian tong server running at http://127.0.0.1:3007')
})