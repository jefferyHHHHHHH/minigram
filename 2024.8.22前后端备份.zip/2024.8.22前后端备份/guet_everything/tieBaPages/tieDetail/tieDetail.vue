<template>
	<view>
		<uni-nav-bar title="贴吧" statusBar='true' backgroundColor='#447db9' color='#eaebeb' fixed='true' left-icon="back" @clickLeft="navigateToBack" leftWidth='80'></uni-nav-bar>
		<view class="userInfo">
			<view class="avatar">
				<image src="../../static/backgroundIMG.png"></image>
			</view>
			<view class="name_time">
				<view class="name">小丑姐</view>
				<view class="time">10分钟前</view>
			</view>
		</view>
		<view class="content">
			{{content}}
		</view>
		<view class="imgs_videos">
			<view class="img_vdeoItem" v-if="videos.length!==0" v-for="(videoItem,index) in videos" :key="index">
				<video @fullscreenchange="fullscreenchange" @play="play" :ref="'video' + index" :src="videoItem.src" play-btn-position="center" controls></video>
			</view>
			<view class="img_vdeoItem" v-if="images.length!==0" v-for="(imageItem,index) in images" :key="index">
				<image :src="imageItem.src"></image>
			</view>	
		</view>
		<view class="tablesBox">
			<view class="table"   v-for="(tableItem,index) in tables" :key="index">
				<view class="tableFont">{{tableItem}}</view>
			</view>
		</view>	
		<view class="buttons">
				
				<view class="buttonBox">
					<view class="buttonIcon">
						<image v-if="!hasPaise" src="../../static/点赞 (4).png"></image>
						<image v-else src="../../static/点赞 (5).png"></image>
					</view>
					<view class="buttonFont">27</view>
				</view>
				
				<view class="buttonBox">
					<view class="buttonIcon">
						<image v-if="!hasStore" src="../../static/收藏.png"></image>
						<image v-else src="../../static/收藏 (1).png"></image>
					</view>
					<view v-if="!hasStore" class="buttonFont">收藏</view>
					<view v-else class="buttonFont">取消</view>
				</view>
				
				<view class="buttonBox">
					<view class="buttonIcon">
						<image src="../../static/分享.png"></image>
					</view>
					<view  class="buttonFont">分享</view>
				</view>
				
		</view>
		<view class="commentsCount">
			共 {{comments.length}} 条评论
		</view>
		<view class="commentsBox">
			<view v-for="(commentItem,index) in comments" :key="index" class="commentItem">
				<view class="commentAvatar">
					<image :src="commentItem.avatar"></image>
				</view>
				<view class="detailBox">
					<view class="name_tag_time_paise">
						<view class="name_tag_time">
							<view class="comName">{{commentItem.nickName}} </view>
							<view class="tag" v-if="commentItem.tag">{{commentItem.tag}}</view>
							<view class="comTime"> · {{commentItem.time}}</view>
						</view>	
						<view class="commentPaiseIcon">
							<image v-if="commentItem.hasPaise" src="../../static/点赞 (5).png"></image>
							<image v-else src="../../static/点赞 (4).png"></image>
						</view>
					</view>
					<view class="commentContent">{{commentItem.content}}</view>
					<view class="aswerTitle">
						<view class="aswerCount">共有 {{commentItem.comments.length}} 条回复</view>
						<view class="rightArrow">
							<image src="../../static/前进.png"></image>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script setup>
	const content = '本来计划好做jiajiao的，结果被放了好几只格子在杭州入不敷出了。。。'
	const tables = ['#吐槽爆料','#AI回答']
	const comments = [
		{
			nickName:'810(回家版)',
			time:'7.20',
			openid:'12312312312312123',
			content:'服了哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈',
			avatar:'../../static/头像.png',
			hasPaise:false,
			comments:[
				{
					nickName:'810(回家版)',
					time:'7.20',
					openid:'12312312312312123',
					content:'服了哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈',
					avatar:'../../static/头像.png',
				}
			]
		},{
			nickName:'810(回家版)',
			time:'7.20',
			openid:'12312312312312123',
			content:'服了哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈',
			avatar:'../../static/头像.png',
			hasPaise:false,
			comments:[
				{
					nickName:'810(回家版)',
					time:'7.20',
					openid:'12312312312312123',
					content:'服了哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈',
					avatar:'../../static/头像.png',
				}
			]
		},{
			nickName:'810(回家版)',
			time:'7.20',
			openid:'12312312312312123',
			content:'服了哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈',
			avatar:'../../static/头像.png',
			hasPaise:false,
			comments:[
				{
					nickName:'810(回家版)',
					time:'7.20',
					openid:'12312312312312123',
					content:'服了哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈',
					avatar:'../../static/头像.png',
				}
			]
		}
	]
	const videos =[
		{
			src:'https://vodpub1.v.news.cn/original/20210609/802da0b3c2ab4238abaf266fa9480dde.mp4'
		},
		]
	const images =[
		{
			src:'../../static/backgroundIMG.png'
		},
		{
			src:'../../static/backgroundIMG.png'
		},
		]
	
	// 播放时进入全屏
	function play(event) {
		let videoContext = uni.createVideoContext(event.target.id, this)
		videoContext.requestFullScreen()
	}
	
	//退出全屏时停止
	function fullscreenchange (event){
		if(!event.detail.fullScreen){
			const videoContext = uni.createVideoContext(event.target.id, this);
			videoContext.stop();
		}
	}
	function navigateToBack (){
		uni.navigateBack()
	}
</script>

<style>
	.userInfo{
		background-color: #ffffff;
		display: flex;
		padding: 30rpx;
		align-items: center;
	}
	.avatar{}
	.avatar image{
		width: 100rpx;
		height: 100rpx;
		border-radius: 80rpx;
	}
	.name_time{
		margin-left: 20rpx;
	}
	.name{
		font-size: 30rpx;
		color: black;
		font-weight: 600;
	}
	.time{
		margin-top: 10rpx;
		font-size: 24rpx;
		color: #a6a6a6;
	}
	.content{
		background-color: #ffffff;
		padding: 0 30rpx 30rpx;
		font-size: 33rpx;
		color: #383838;
		line-height: 40rpx;
		letter-spacing: 3rpx;
	}
	.table{
		margin-left: 20rpx;
		background-color: #e2f0ff;
		padding: 15rpx;
		min-width: 50rpx;
		max-width: 140rpx;
		padding: 10rpx;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.tableFont{
		color: #576070;
		font-size: 24rpx;
	}
	.buttons{
		background-color: #ffffff;
		display: flex;
		padding-top: 25rpx;
		padding-left: 300rpx;
	}
	.buttonBox{
		display: flex;
		margin-left: 50rpx;
	}
	.buttonIcon{}
	.buttonIcon image{
		width: 35rpx;
		height: 35rpx;
	}
	.buttonIcon image:last-of-type{
		width: 26rpx;
		height: 26rpx;
	}
	.buttonFont{
		font-size: 25rpx;
		color:#9d9d9d ;
		margin-left: 10rpx;
	}
	.tablesBox {
		display: flex;
		padding-left: 30rpx;
		background-color: #ffffff;
	}
	.imgs_videos{
		display: flex;
		padding: 30rpx;
		background-color: #ffffff;
		flex-wrap: wrap;
		justify-content: space-around;
		align-items: center;
	}
	.img_vdeoItem video{
		width: 220rpx;
		height: 220rpx;
	}
	.img_vdeoItem image{
		width: 220rpx;
		height: 220rpx;
	}
	.img_videoItem{
		margin-left: 20rpx;
	}
	.commentsCount{
		font-size: 27rpx;
		color: #4c5462;
		margin:30rpx ;
	}
	.commentAvatar image{
		width: 70rpx;
		height: 70rpx;
		border-radius: 70rpx;
		
	}
	.commentPaiseIcon image{
		width: 40rpx;
		height: 40rpx;
	}
	.rightArrow{
		width: 40rpx;
		height: 40rpx;
	}
	.name_tag_time_paise{
		display: flex;
		justify-content: space-between;
		align-items: center;
		width:580rpx ;
	}
	.name_tag_time{
		display: flex;
		align-items: center;
	}
	.commentItem{
		display: flex;
		padding: 10rpx 30rpx 10rpx 30rpx;
		width: calc(100%-30rpx);
		
	}
	.detailBox{
		padding: 10rpx 20rpx 10rpx 20rpx;
	}
	.comTime{
		font-size: 24rpx;
		color: #a6a6a6;
		
	}
	.comName{
		font-size: 26rpx;
		color: #5b5b5b;
		font-weight: 600rpx;
	}
	.commentContent {
		padding: 20rpx 0 20rpx 0;
		width: 530rpx;
		font-size: 29rpx;
		letter-spacing: 3rpx;
		line-height: 35rpx;
	}
	.aswerCount {
		font-size: 27rpx;
		color: #415376;
	}
	.rightArrow image{
		width: 30rpx;
		height: 30rpx;
	}
	.rightArrow {
		margin-left: 10rpx;
	}
	.aswerTitle{
		display: flex;
		align-items: center;
	}
</style>
