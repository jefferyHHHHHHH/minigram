<template>
	<view>
		<uni-nav-bar title="搜索" statusBar='true' backgroundColor='#447db9' color='#eaebeb' fixed='true' left-icon="back" @clickLeft="navigateBack" leftWidth=80></uni-nav-bar>
		<view class="searchBox">
			<view class="searchArea">
				<view class="searchIcon">
					<image src="../../static/搜索.png"></image>
				</view>
				<view class="searchWord">
					<input />
				</view>
			</view>
			<view class="hotSearch">
				<view class="hotFont">热搜</view>
				<view class="hotView">
					<scroll-view scroll-x>
						<view class="hotInfoView">
							<view class="hotItem" v-for="(hotItem,index) in hotArray">
								<view class="hotInfo">{{hotItem.content}}</view>
							</view>
						</view>	
					</scroll-view>
				</view>
			</view>
		</view>
	</view>
</template>

<script setup>
	const hotArray=[
		{
			content:'军训'
		},
		{
			content:'加分'
		},
		{
			content:'见习'
		},
		{
			content:'帮忙'
		},
		{
			content:'搬东西'
		},
		{
			content:'手机膜'
		},
		{
			content:'得分'
		},
		{
			content:'三级'
		},
	]
	function navigateBack(){
		uni.navigateBack()
	}
</script>
	
<style>
	.searchBox{
		height: 170rpx;
		background-color:#447db9 ;
	}  
	.searchArea{
		width: 92%;
		margin-left: 4%;
		background-color: #ffffff;
		border-radius: 30rpx;
		display: flex;
		align-items: center;
		height: 50rpx;
		padding: 10rpx 20rpx;
	}
	.searchIcon image{
		width: 40rpx;
		height: 40rpx;
	}
	.searchWord{
		margin-left: 10rpx;
	}
	.hotSearch{
		margin-top: 20rpx;
		display: flex;
		
	}
	.hotFont{
		width: 30rpx;
		font-size: 24rpx;
		color: #ffffff;
		background-color:#ff4548;
		margin-left:4%;
		border-radius: 10rpx;
		padding: 5rpx;
	}
	.hotInfoView {
	  display: flex;
	  flex-direction: row;
	  overflow-x: auto; /* 确保scroll-view滚动方向为横向 */
	  white-space: nowrap; /* 防止换行 */
	}
	.hotView {
		display: flex;
		justify-content: space-around;
	}
	.hotItem {
		padding: 10rpx;
		color: #ffffff;
		font-size: 26rpx;
		border: 1rpx solid #ffffff;
		border-radius: 30rpx;
		margin-right: 15rpx;
	}
	.hotView scroll-view{
		width: 630rpx;
		margin-left: 20rpx;
	}
	
	
	
</style>
