import refreshTokenGlobal from './libs/refreshTokenGlobal.js'

const glbFunction = {
	refreshTokenGlobal
}

export default {
	glbFunction
}