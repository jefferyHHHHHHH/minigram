<template>
	<view>
		<uni-nav-bar title="消息" statusBar='true' backgroundColor='#447db9' color='#eaebeb' fixed='true' ></uni-nav-bar>
		<view class="detailsBOx">
			<view class="detailItem">
				<view class="detailIcon">
					<image src="../../static/评论.png"></image>
				</view>
				<view class="detailFont">评论</view>
			</view>
			<view class="detailItem">
				<view class="detailIcon">
					<image src="../../static/赞_fill.png"></image>
				</view>
				<view class="detailFont">赞</view>
			</view>
			<view class="detailItem">
				<view class="detailIcon">
					<image src="../../static/tabbar3_s (4).png"></image>
				</view>
				<view class="detailFont">攒局</view>
			</view>
			<view class="detailItem">
				<view class="detailIcon">
					<image src="../../static/message.png"></image>
				</view>
				<view class="detailFont">私聊</view>
			</view>
		</view>
		 
		<view class="dongtai">
			<view class="title">
				<view class="titleFont">帖子动态</view>
				<view class="yiduBox">
					<view class="yiduFont">全部已读</view>
					<view class="yiduIcon">
						<image src="../../static/打勾.png"></image>
					</view>
				</view>
			</view>
			<view class="content">
				<view class="nullMessage" v-if="none==true">暂无消息</view>
			</view>
		</view>
	</view>
</template>

<script setup>
	var none = true
</script>

<style>
	.detailsBOx {
		padding-top: 20rpx;
		padding-bottom: 10rpx;
		display:flex;
		justify-content: space-around;
		align-items: center;
		background-color: #ffffff;
	}
	.detailItem{
		display: flex; 
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}
	.detailIcon{
		width: 100rpx;
		height: 100rpx;
		border-radius: 100%;
		display: flex;
		justify-content: center;
		align-items: center;
		background-color: #0b8bc6;
		margin-bottom: 10rpx;
	}
	.detailIcon image{
		width: 50rpx;
		height: 50rpx;
	} 
	.detailFont {
		color: #202020;
		font-size: 27rpx;
		font-weight: 600;
	}
	.dongtai{
		
	}
	.title{
		background-color: #ffffff;
		display: flex;
		justify-content: space-between;
		padding: 15rpx 30rpx 15rpx;
		/* border-bottom: #1b465f solid 3rpx; */
		margin-top: 10rpx;
		margin-bottom: 20rpx;
		/* border-top: #1b465f solid 3rpx; */
		margin-top: 30rpx;
	}
	.titleFont{
		color:#202020 ;
		font-weight: 600;
		font-size: 29rpx;
	}
	.yiduBox{
		display: flex;
		align-items: center;
	}
	.yiduFont{
		font-size: 25rpx;
		color:#585858 ;
		opacity: 0.7;
	}
	.yiduIcon image{
		margin-left: 10rpx;
		width: 20rpx;
		height: 20rpx;
	}
	.nullMessage{
		text-align: center;
		margin-top: 30rpx;
		font-size: 26rpx;
		color: #646464;
	}
</style>
