const { query, response } = require('express')
const db = require('../db/index')
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')
const config = require('../config')
const axios = require('axios')
const { gettimeago } = require('../methods/gettimeago')
// const bcryptjs = require('bcrypt')

exports.regUser = (req, res) => {
    const userinfo = req.body
    const sql = 'select * from userinfo where username=?'
    if (!userinfo.username || !userinfo.password) {
        return res.cc('用户名或密码不能为空！')
    }
    db.query(sql, userinfo.username, (err, results) => {
        if (err) {
            return res.cc(err)
        }
        if (results.length > 0) {
            return res.cc('用户名被占用，请更换其他用户名')
        }
        const insertSql = 'insert into userinfo set?'
        const saltRounds = 5
        const hashPassword = bcrypt.hashSync(userinfo.password, saltRounds)
        userinfo.password = hashPassword
        db.query(insertSql, userinfo, (err, results) => {
            if (err) {
                return res.cc(err)
            }

            if (results.affectedRows === 1) {
                res.send({
                    status: 200,
                    message: results
                })
            } else {
                res.cc('注册失败！数据插入失败！')
            }
        })



    })
}

exports.login = (req, res) => {
    const userinfo = req.body
    const sql = 'select * from userinfo where username=?'
    db.query(sql, userinfo.username, (err, results) => {
        if (err) return res.cc(err)
        if (results.length !== 1) return res.cc('登录失败，查询不到对应的数据！')
        const compareResult = bcrypt.compareSync(userinfo.password, results[0].password)
        if (!compareResult) {
            return res.cc('登陆失败！')
        }
        const user = { ...results[0], userPic: '', password: '' }
        const accessToken = jwt.sign(user, config.jwtSecreKey, {
            expiresIn: '3h'
        })
        const refreshToken = jwt.sign(user, config.jwtSecreKey, {
            expiresIn: '3d'
        })
        if (compareResult) {
            return res.send({
                message: '登录成功',
                accessToken: 'Bearer ' + accessToken,
                refreshToken: 'Bearer' + refreshToken
            })
        }
    })
}
exports.refreshToken = (req, res) => {
    console.log(req.query)
    const token = req.query.refreshToken
    try {
        const openid = jwt.verify(token, config.jwtSecreKey).openid
        const accessToken = jwt.sign({ openid }, config.jwtSecreKey, {
            expiresIn: '3h'
        })
        const refreshToken = jwt.sign({ openid }, config.jwtSecreKey, {
            expiresIn: '3d'
        })
        res.send({
            code: 200,
            data: {
                accessToken: accessToken,
                refreshToken: refreshToken
            }
        })
    } catch (err) {
        console.log(err)
        return res.cc('token无效,请重新登录')
    }
}
exports.trylogin = async (req, res) => {
    console.log('~~~~~~~~~~~~~~~~~~~~~')
    console.log(req.body, 'show req.body');
    const code = req.body.code;
    const userInfo = req.body.userInfo;
    const loginData = {
        appid: config.appid,
        appsecret: config.appsecret
    };
    const timestamp = Date.now();
    const wxUrl = `https://api.weixin.qq.com/sns/jscode2session?appid=${loginData.appid}&secret=${loginData.appsecret}&js_code=${code}`;

    try {
        const response = await axios.post(wxUrl);
        console.log(response.data, 'show wxUrl response');
        const openid = response.data.openid;
        const accessToken = jwt.sign({ openid }, config.jwtSecreKey, { expiresIn: '3h' });
        const refreshToken = jwt.sign({ openid }, config.jwtSecreKey, { expiresIn: '3d' });
        const searchSql = 'SELECT * FROM userinfo WHERE openid = ?';
        db.query(searchSql, [openid], (err, results) => {
            if (err) {
                return res.cc(err);
            }
            //can not find data in the database byopenid and the userInfo is not null,insert data
            if (results.length === 0 && userInfo) {
                console.log('1')
                const insertSql = 'INSERT INTO userinfo (nickname, avatarUrl, openid,gender,create_time) VALUES (?, ?, ?,?,?)';
                db.query(insertSql, [userInfo.nickName, userInfo.avatarUrl, openid, userInfo.gender, timestamp], (err, insertResults) => {
                    if (err) {
                        return res.cc(err);
                    }
                    return res.send({
                        message: 'User information inserted',
                        success: true,
                        accessToken: accessToken,
                        refreshToken: refreshToken,
                        sessionKey: response.data.session_key,
                        openid: openid,
                        create_time: timestamp
                    });
                });
                //can find data in the database byopenid and the userInfo is not null,update Data
            } else if (results.length !== 0 && userInfo) {
                console.log('2')
                const updateSql = 'UPDATE userinfo SET nickname = ?, avatarUrl = ? ,gender =?,modifed_time =? WHERE openid = ?';
                db.query(updateSql, [userInfo.nickName, userInfo.avatarUrl, userInfo.gender, timestamp, openid], (err, updateResults) => {
                    if (err) {
                        return res.cc(err);
                    }
                    return res.send({
                        message: 'Personal information updated',
                        success: true,
                        accessToken: accessToken,
                        refreshToken: refreshToken,
                        sessionKey: response.data.session_key,
                        openid: openid,
                        modifed_time: timestamp
                    });
                });
                //database has the data,and return it
            } else if (results.length !== 0 && !userInfo) {
                console.log('3', results[0])
                if (results[0]?.nickname && results[0]?.avatarUrl) {
                    return res.send({
                        userInfo: results[0],
                        success: true,
                        accessToken: accessToken,
                        refreshToken: refreshToken,
                        sessionKey: response.data.session_key,
                        openid: openid
                    });
                } else {
                    return res.send({
                        message: 'No detailed user information',
                        success: true,
                        accessToken: accessToken,
                        refreshToken: refreshToken,
                        sessionKey: response.data.session_key,
                        openid: openid
                    });
                }
            } else if (results.length == 0 && !userInfo) {
                console.log('4')
                const insertNormalSql = 'INSERT INTO userinfo (openid,create_time) VALUES (?,?)';
                db.query(insertNormalSql, [openid, timestamp], (err, res) => {
                    if (err) return res.cc(err)
                    return res.send({
                        accessToken: accessToken,
                        refreshToken: refreshToken,
                        sessionKey: response.data.session_key,
                        openid: openid,
                        create_time: timestamp,
                    })
                })
            }
        });
    } catch (error) {
        console.error('Login failed', error);
        return res.cc(error);
    }
};
exports.showTieZi = async (req, res) => {
    const { cursorId } = req.query;
    const token = req.headers.authorization.slice(7);
    var openid = ''
    console.log(token)
    jwt.verify(token, config.jwtSecreKey, (err, decoded) => {
        if (err) return res.cc(err)
        console.log(decoded)
        openid = decoded.openid
        let limitClause = 'LIMIT 2';
        let whereClause = cursorId ? `AND t.tieId < ${cursorId}` : '';
        const postsQuery = `
    SELECT 
        t.tieId,
        t.content,
        t.images,
        t.tag,
        t.videos,
        t.publish_time,
        u.avatarUrl,
        u.nickname,
        COUNT(DISTINCT c.commentId) AS comment_count,
        COUNT(DISTINCT p.paiseId) AS like_count,
        COUNT(DISTINCT CASE WHEN p.sendId = '${openid}' THEN p.paiseId END) AS hasPaise,
        COUNT(DISTINCT s.storeId) AS store_count,
        COUNT(DISTINCT CASE WHEN s.storerId = '${openid}' THEN s.storeId END) AS hasStore
    FROM 
        tiearray t
    JOIN 
        userInfo u ON t.authorId = u.openid
    LEFT JOIN 
        paisearray p ON t.tieId = p.acceptId
    LEFT JOIN 
        storelist s ON t.tieId = s.tieId
    LEFT JOIN
        commentlist c ON t.tieId = c.tieId
    WHERE 
        1=1 ${whereClause} 
    GROUP BY 
        t.tieId, u.openid, u.avatarUrl, u.nickname
    ORDER BY 
        t.tieId DESC
    ${limitClause}  
    `;
        db.query(postsQuery, (err, results) => {
            if (err) return res.cc(err)
            var timeAgo = ''
            results.forEach(result => {
                result.timeAgo = gettimeago(result.publish_time)
            });
            res.send(results)
        })
    })

}
exports.showTieDetail = (req, res) => {
    const token = req.headers.authorization.slice(7);
    const tieId = req.query.tieId
    jwt.verify(token, config.jwtSecreKey, (err, decoded) => {
        if (err) return res.cc(err)
        const openid = decoded.openid
        const sql = `SELECT
    t.tieId,
    t.content AS postContent,
    t.publish_time AS postPublishTime,
    u.openid AS authorOpenid,
    u.avatarUrl AS authorAvatarUrl,
    u.nickname AS authorNickname,
    COUNT(p.paiseId) AS like_count,
    COUNT(s.storeId) AS store_count,
    c.commentId,
    c.cmet_content AS commentContent,
    c.openid AS commenterOpenid,
    u2.avatarUrl AS commenterAvatarUrl,
    u2.nickname AS commenterNickname,
    c.dadCommentId AS parentCommentId, 
    COUNT(DISTINCT c.commentId) AS comment_count,
    COUNT(DISTINCT p.paiseId) AS like_count,
    COUNT(DISTINCT CASE WHEN p.sendId = '${openid}' THEN p.paiseId END) AS hasPaise,
    COUNT(cp.paiseId) AS comment_like_count,
    COUNT(DISTINCT s.storeId) AS store_count,
    COUNT(DISTINCT CASE WHEN s.storerId = '${openid}' THEN s.storeId END) AS hasStore
FROM
    tiearray t
JOIN
    userInfo u ON t.authorId = u.openid
LEFT JOIN
    paisearray p ON t.tieId = p.acceptId
LEFT JOIN
    storelist s ON t.tieId = s.tieId
LEFT JOIN
    commentlist c ON c.tieId = t.tieId
LEFT JOIN
    userInfo u2 ON c.openid = u2.openid
LEFT JOIN
    paisearray cp ON cp.acceptId = c.commentId
WHERE t.tieId = ${tieId}
GROUP BY
    t.tieId,c.commentId
ORDER BY
    (CASE WHEN c.dadCommentID = -1 THEN 1 ELSE 2 END),
    c.commentId DESC;`
        db.query(sql, (err, results) => {
            if (err) return res.cc(err)
            console.log(results)
            res.send(results)
        })
    })
}