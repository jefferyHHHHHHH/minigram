const { query } = require('express')
const db = require('../db/index')
const bcrypt = require('bcryptjs')
// const bcryptjs = require('bcrypt')
const jwt = require('jsonwebtoken')
const config = require('../config')

exports.updateUserInfo = (req, res) => {
    console.log(req.auth)
    const sql = 'update * from userinfo set ? where openid =?'
    const newUserInfo = req.body
    const openid = req.auth.openid
    db.query(sql, [newUserInfo, openid], (err, results) => {
        if (err) {
            console.log(err)
            return res.cc(err)
        }
        if (results.affectedRows === 1) return res.send({
            status: 200,
            message: '数据修改成功！'
        })

    })
}
exports.updatePassword = (req, res) => {
    const openid = req.auth.openid
    const oldpassword = req.body.oldpassword
    const newpassword = req.body.newpassword
    const sql = 'select * from userinfo where openid=?'
    db.query(sql, openid, (err, results) => {
        if (err) return res.cc(err)
        const compareResult = bcrypt.compareSync(oldpassword, results[0].password)
        if (!compareResult) return res.cc('密码错误！')
        const updateSql = 'update  from userinfo  '
    })
}
exports.getUserInfo = (req, res) => {
    const sql = 'select * from userinfo where openid=?'
    console.log(req.query)
    openid = req.query.openid
    db.query(sql, openid, (err, results) => {
        if (err) return res.cc("找不到对应用户的信息" + openid)
        console.log(results)
        return res.send({
            status: 202,
            data: results[0],
            message: '获取相应用户信息成功！'
        })
    })
}
exports.autoLogin = (req, res) => {
    const openid = req.auth.openid
    const sql = 'select * from userinfo where openid = ?'
    db.query(sql, openid, (err, results) => {
        if (err) return res.cc(err)
        const userInfo = {
            avatarUrl: results[0].avatarUrl,
            gender: results[0].gender,
            nickname: results[0].nickname,
            major: results[0].major
        }
        return res.send({
            status: 202,
            userInfo: userInfo,
            message: '自动登录成功！'
        })
    })
}
exports.tieziPublish = (req, res) => {
    const tieInfo = req.body.tieInfo
    // tieInfo.images = JSON.stringify(tieInfo.images)
    // tieInfo.videos = JSON.stringify(tieInfo.videos)
    tieInfo.authorId = req.auth.openid
    if (tieInfo.images.length === 0) {
        tieInfo.images = null
    }
    if (tieInfo.videos.length === 0) {
        tieInfo.videos = null
    }
    console.log(tieInfo)
    const querySql = 'INSERT INTO tiearray (authorId,publish_time,content,tag,images,videos) VALUES (?,?,?,?,?,?)'
    db.query(querySql, [tieInfo.authorId, tieInfo.publish_time, tieInfo.content, tieInfo.tag, tieInfo.images, tieInfo.videos], (err, results) => {
        console.log(results)
        console.log(err)
        if (err) return res.send({ message: '插入帖子信息错误' })
        if (results.affectedRows === 1)
            return res.send({
                status: 202,
                success: true,
            })
        return res.send({ message: '插入帖子失败' })
    })
}
exports.toPaise = (req, res) => {
    console.log(req.body, req.auth.openid)
    const sendId = req.auth.openid
    const acceptId = req.body.acceptId
    const send_time = req.body.send_time
    const type = req.body.type
    const sql = 'INSERT INTO paisearray (sendId,acceptId,send_time,type) VALUES (?,?,?,?)'
    db.query(sql, [sendId, acceptId, send_time, type], (err, results) => {
        if (err) return res.cc(err)
        console.log(results)
        res.send({
            message: '点赞成功！',
            status: 200
        })
    })
}
exports.toStopPaise = (req, res) => {
    console.log(req.body, req.auth.openid)
    const sendId = req.auth.openid
    const acceptId = req.body.acceptId
    const sql = 'DELETE FROM paisearray WHERE sendId = ? AND acceptId = ? '
    db.query(sql, [sendId, acceptId], (err, results) => {
        if (err) return res.cc(err)
        console.log(results)
        res.send({
            message: '取消点赞成功！',
            status: 200
        })
    })
}
exports.toStore = (req, res) => {
    const tieId = req.body.tieId
    const storerId = req.auth.openid
    const store_time = req.body.store_time
    const sql = 'INSERT INTO storelist (tieId,storerId,store_time) VALUES (?,?,?)'
    db.query(sql, [tieId, storerId, store_time], (err, results) => {
        if (err) return res.cc(err)
        console.log(results)
        res.send({
            message: '收藏成功！',
            status: 200
        })
    })
}
exports.toStopStore = (req, res) => {
    const tieId = req.body.tieId
    const storerId = req.auth.openid
    const sql = 'DELETE FROM storelist WHERE tieId = ? AND storerId = ? '
    db.query(sql, [tieId, storerId], (err, results) => {
        if (err) return res.cc(err)
        console.log(results)
        res.send({
            message: '取消收藏成功！',
            status: 200
        })
    })

}