module.exports = {
    jwtSecreKey: 'guet_kexie',
    appid: 'wxb7d0b68af39c9e46',
    appsecret: 'ae79196172d6c443e3a0484cba2db6fd',
    aesSecretKey: 'nolonger'
}